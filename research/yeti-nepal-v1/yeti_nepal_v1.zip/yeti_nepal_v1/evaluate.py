"""
Evaluate Yeti Nepal v1
========================
Runs perplexity, GSM8K-style accuracy, and basic generation checks.
Usage:
    python evaluate.py --checkpoint ./checkpoints/phase2_final_step1000.pt
"""

import argparse
import math
import torch
from transformers import AutoTokenizer

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from config.model_config import get_full_config
from model.yeti_core import YetiForCausalLM


# ─────────────────────────────────────────────────────────────────────
# Perplexity
# ─────────────────────────────────────────────────────────────────────

def compute_perplexity(model, tokenizer, texts, device, max_len=512):
    model.eval()
    total_nll, total_tokens = 0.0, 0
    with torch.no_grad():
        for text in texts:
            ids = tokenizer.encode(text, return_tensors="pt",
                                   max_length=max_len, truncation=True).to(device)
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                out = model(input_ids=ids, labels=ids)
            n   = (ids != tokenizer.pad_token_id).sum().item()
            total_nll    += out["loss"].item() * n
            total_tokens += n
    ppl = math.exp(total_nll / max(total_tokens, 1))
    return round(ppl, 3)


# ─────────────────────────────────────────────────────────────────────
# Simple generation accuracy (greedy decode + answer extraction)
# ─────────────────────────────────────────────────────────────────────

def evaluate_reasoning(model, tokenizer, qa_pairs, device,
                        max_new_tokens=128, temperature=0.1):
    """
    qa_pairs: list of {"question": ..., "answer": ...}
    Returns accuracy as float.
    """
    model.eval()
    correct = 0
    for item in qa_pairs:
        prompt = f"<|user|>\n{item['question']}\n<|assistant|>\n"
        ids    = tokenizer.encode(prompt, return_tensors="pt").to(device)
        generated = model.generate_simple(
            ids, max_new_tokens=max_new_tokens,
            temperature=temperature, top_k=1,   # greedy
            eos_token_id=tokenizer.eos_token_id,
        )
        decoded = tokenizer.decode(generated[0], skip_special_tokens=True)
        # Extract <answer> tag if present
        import re
        m = re.search(r"<answer>(.*?)</answer>", decoded, re.DOTALL)
        pred = m.group(1).strip() if m else decoded.split("\n")[-1].strip()
        if str(item["answer"]).strip().lower() in pred.lower():
            correct += 1

    return correct / max(len(qa_pairs), 1)


# ─────────────────────────────────────────────────────────────────────
# Built-in mini eval set
# ─────────────────────────────────────────────────────────────────────

MINI_EVAL = [
    {"question": "What is 12 * 15?", "answer": "180"},
    {"question": "What is the capital of France?", "answer": "Paris"},
    {"question": "Solve: x + 5 = 12. What is x?", "answer": "7"},
    {"question": "What is 2 to the power of 10?", "answer": "1024"},
    {"question": "What is the square root of 144?", "answer": "12"},
]

PRETRAIN_EVAL_TEXTS = [
    "The capital of Nepal is Kathmandu, located in the Kathmandu Valley.",
    "Machine learning is a subset of artificial intelligence focused on data-driven algorithms.",
    "The quadratic formula is x = (-b ± √(b²-4ac)) / 2a.",
]


# ─────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--tokenizer",  type=str, default="mistralai/Mistral-7B-v0.1")
    parser.add_argument("--device",     type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    print(f"Loading model from: {args.checkpoint}")
    config = get_full_config()
    model  = YetiForCausalLM(config)
    state  = torch.load(args.checkpoint, map_location="cpu")
    model.load_state_dict(state.get("model", state), strict=False)
    model.to(args.device)

    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer, use_fast=True)
    tokenizer.pad_token = tokenizer.eos_token

    print("\n── Perplexity ──")
    ppl = compute_perplexity(model, tokenizer, PRETRAIN_EVAL_TEXTS, args.device)
    print(f"  Perplexity: {ppl}")

    print("\n── Reasoning Accuracy (mini-eval) ──")
    acc = evaluate_reasoning(model, tokenizer, MINI_EVAL, args.device)
    print(f"  Accuracy: {acc * 100:.1f}% ({int(acc * len(MINI_EVAL))}/{len(MINI_EVAL)})")

    print("\n── Sample Generation ──")
    prompt = "<|user|>\nExplain what a neural network is in 2 sentences.\n<|assistant|>\n"
    ids    = tokenizer.encode(prompt, return_tensors="pt").to(args.device)
    out = model.generate_simple(
        ids, max_new_tokens=80, temperature=0.7,
        eos_token_id=tokenizer.eos_token_id,
    )
    print(tokenizer.decode(out[0], skip_special_tokens=True))

    print(f"\n── Model Size ──")
    params = model.count_parameters()
    print(f"  Total:     {params['total_M']} M")
    print(f"  Trainable: {params['trainable_M']} M")


if __name__ == "__main__":
    main()
