"""
Yeti Trainer — Three-Phase Training Loop
==========================================
Phase 1: Autoregressive pretraining (FineWeb-Edu)
Phase 2: SFT with instruction + CoT data
Phase 3: DPO alignment

Designed for Google Colab T4 with Unsloth + BF16.
"""

import os
import math
import time
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, LinearLR, SequentialLR
from torch.cuda.amp import GradScaler, autocast
from typing import Optional

try:
    from train.loss_functions import YetiLoss      # when run as script
except ImportError:
    from .loss_functions import YetiLoss            # when imported as module


# ─────────────────────────────────────────────────────────────────────
# Utilities
# ─────────────────────────────────────────────────────────────────────

def get_cosine_schedule_with_warmup(optimizer, warmup_steps: int, total_steps: int):
    warmup = LinearLR(optimizer, start_factor=1e-8, end_factor=1.0, total_iters=warmup_steps)
    cosine = CosineAnnealingLR(optimizer, T_max=max(total_steps - warmup_steps, 1), eta_min=0)
    return SequentialLR(optimizer, schedulers=[warmup, cosine], milestones=[warmup_steps])


def save_checkpoint(model, optimizer, scheduler, step: int, path: str, tag: str = "ckpt"):
    os.makedirs(path, exist_ok=True)
    state = {
        "step":      step,
        "model":     model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict() if scheduler else None,
    }
    fpath = os.path.join(path, f"{tag}_step{step}.pt")
    torch.save(state, fpath)
    print(f"[Checkpoint] Saved → {fpath}")
    return fpath


def load_checkpoint(model, optimizer, scheduler, path: str):
    state = torch.load(path, map_location="cpu")
    model.load_state_dict(state["model"])
    optimizer.load_state_dict(state["optimizer"])
    if scheduler and state.get("scheduler"):
        scheduler.load_state_dict(state["scheduler"])
    print(f"[Checkpoint] Resumed from step {state['step']} ← {path}")
    return state["step"]


def estimate_total_steps(total_tokens: int, seq_len: int,
                          batch_size: int, grad_accum: int) -> int:
    tokens_per_step = seq_len * batch_size * grad_accum
    return math.ceil(total_tokens / tokens_per_step)


# ─────────────────────────────────────────────────────────────────────
# Phase 1 — Pretraining
# ─────────────────────────────────────────────────────────────────────

def run_phase1(model, dataloader, cfg, device, resume_from: Optional[str] = None):
    """Autoregressive pretraining on FineWeb-Edu."""
    print("\n" + "=" * 55)
    print("  PHASE 1 — PRETRAINING")
    print("=" * 55)

    model.to(device)
    model.train()

    yeti_loss = YetiLoss(model.config)
    optimizer = AdamW(
        model.parameters(),
        lr=cfg.learning_rate,
        betas=(cfg.adam_beta1, cfg.adam_beta2),
        eps=cfg.adam_epsilon,
        weight_decay=cfg.weight_decay,
    )

    total_steps   = estimate_total_steps(cfg.max_train_tokens, cfg.seq_len_max,
                                         cfg.per_device_train_batch_size,
                                         cfg.gradient_accumulation_steps)
    warmup_steps  = max(1, int(total_steps * cfg.warmup_ratio))
    scheduler     = get_cosine_schedule_with_warmup(optimizer, warmup_steps, total_steps)
    scaler        = GradScaler(enabled=cfg.bf16)

    global_step = 0
    accum_loss  = 0.0
    t0          = time.time()

    if resume_from:
        global_step = load_checkpoint(model, optimizer, scheduler, resume_from)

    optimizer.zero_grad()

    for batch in dataloader:
        input_ids = batch["input_ids"].to(device)
        labels    = batch["labels"].to(device)

        with autocast(dtype=torch.bfloat16, enabled=cfg.bf16):
            out = model(input_ids=input_ids, labels=labels)
            ce  = out["loss"]
            loss, breakdown = yeti_loss(model, ce)
            loss = loss / cfg.gradient_accumulation_steps

        scaler.scale(loss).backward()
        accum_loss += loss.item()

        if (global_step + 1) % cfg.gradient_accumulation_steps == 0:
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), cfg.max_grad_norm)
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            optimizer.zero_grad()

            opt_step = (global_step + 1) // cfg.gradient_accumulation_steps
            if opt_step % cfg.logging_steps == 0:
                elapsed = time.time() - t0
                lr_now  = scheduler.get_last_lr()[0]
                print(f"  step={opt_step:6d} | loss={accum_loss:.4f} | "
                      f"ce={breakdown['loss_ce']:.4f} | "
                      f"bal={breakdown['loss_balance']:.5f} | "
                      f"z={breakdown['loss_z']:.5f} | "
                      f"lr={lr_now:.2e} | t={elapsed:.1f}s")
                accum_loss = 0.0

            if opt_step % cfg.save_steps == 0:
                save_checkpoint(model, optimizer, scheduler, opt_step, cfg.output_dir)

        global_step += 1

    save_checkpoint(model, optimizer, scheduler, global_step, cfg.output_dir, tag="phase1_final")
    print("\n[Phase 1] ✓ Done.")
    return model


# ─────────────────────────────────────────────────────────────────────
# Phase 2 — Supervised Fine-Tuning
# ─────────────────────────────────────────────────────────────────────

def run_phase2(model, dataloader, cfg, device, resume_from: Optional[str] = None):
    """SFT on OpenHermes + Open-Orca CoT with LoRA (if enabled)."""
    print("\n" + "=" * 55)
    print("  PHASE 2 — SUPERVISED FINE-TUNING (SFT)")
    print("=" * 55)

    if cfg.use_lora:
        try:
            from peft import get_peft_model, LoraConfig, TaskType
            lora_cfg = LoraConfig(
                r=cfg.lora_r, lora_alpha=cfg.lora_alpha,
                lora_dropout=cfg.lora_dropout,
                target_modules=cfg.lora_target_modules,
                task_type=TaskType.CAUSAL_LM,
            )
            model = get_peft_model(model, lora_cfg)
            model.print_trainable_parameters()
        except ImportError:
            print("[SFT] peft not found — training all parameters.")

    model.to(device)
    model.train()

    # Resolve config through PEFT wrapper chain
    def _get_config(m):
        if hasattr(m, 'config'):
            return m.config
        if hasattr(m, 'base_model') and hasattr(m.base_model, 'model'):
            return m.base_model.model.config
        raise AttributeError("Cannot find model config")

    yeti_loss = YetiLoss(_get_config(model))
    optimizer = AdamW(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=cfg.learning_rate,
        betas=(cfg.adam_beta1, cfg.adam_beta2),
        weight_decay=cfg.weight_decay,
    )

    total_steps  = estimate_total_steps(cfg.max_train_tokens, cfg.seq_len,
                                        cfg.per_device_train_batch_size,
                                        cfg.gradient_accumulation_steps)
    warmup_steps = max(1, int(total_steps * cfg.warmup_ratio))
    scheduler    = get_cosine_schedule_with_warmup(optimizer, warmup_steps, total_steps)
    scaler       = GradScaler(enabled=cfg.bf16)

    global_step = 0
    optimizer.zero_grad()

    for batch in dataloader:
        input_ids = batch["input_ids"].to(device)
        labels    = batch["labels"].to(device)
        attn_mask = batch.get("attention_mask", None)
        if attn_mask is not None:
            attn_mask = attn_mask.to(device)

        with autocast(dtype=torch.bfloat16, enabled=cfg.bf16):
            out = model(input_ids=input_ids, attention_mask=attn_mask, labels=labels)
            ce  = out["loss"]
            # Unwrap PEFT wrapper to access YetiForCausalLM for router logits
            if hasattr(model, 'base_model') and hasattr(model.base_model, 'model'):
                base_model = model.base_model.model
            elif hasattr(model, 'base_model'):
                base_model = model.base_model
            else:
                base_model = model
            loss, breakdown = yeti_loss(base_model, ce)
            loss = loss / cfg.gradient_accumulation_steps

        scaler.scale(loss).backward()

        if (global_step + 1) % cfg.gradient_accumulation_steps == 0:
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), cfg.max_grad_norm)
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            optimizer.zero_grad()

            opt_step = (global_step + 1) // cfg.gradient_accumulation_steps
            if opt_step % cfg.logging_steps == 0:
                print(f"  [SFT] step={opt_step:5d} | ce={breakdown['loss_ce']:.4f} | "
                      f"total={breakdown['loss_total']:.4f}")

            if opt_step % cfg.save_steps == 0:
                save_checkpoint(model, optimizer, scheduler, opt_step, cfg.output_dir, "sft")

        global_step += 1

    save_checkpoint(model, optimizer, scheduler, global_step, cfg.output_dir, "phase2_final")
    print("\n[Phase 2] ✓ Done.")
    return model


# ─────────────────────────────────────────────────────────────────────
# Phase 3 — DPO
# ─────────────────────────────────────────────────────────────────────

def run_phase3(model, tokenizer, dpo_dataset, cfg, device):
    """
    Direct Preference Optimisation using the TRL DPOTrainer.
    Requires: pip install trl>=0.8.0
    """
    print("\n" + "=" * 55)
    print("  PHASE 3 — DPO ALIGNMENT")
    print("=" * 55)

    try:
        from trl import DPOTrainer, DPOConfig
        from peft import get_peft_model, LoraConfig, TaskType
    except ImportError as e:
        print(f"[DPO] Missing dependency: {e}\n  Run: pip install trl peft")
        return model

    if cfg.use_lora:
        lora_cfg = LoraConfig(
            r=cfg.lora_r, lora_alpha=cfg.lora_alpha,
            lora_dropout=cfg.lora_dropout,
            task_type=TaskType.CAUSAL_LM,
        )
        model = get_peft_model(model, lora_cfg)

    # Convert streaming dataset to HF Dataset for DPOTrainer
    from datasets import Dataset as HFDataset
    rows = [ex for ex in dpo_dataset]
    hf_ds = HFDataset.from_list(rows)

    training_args = DPOConfig(
        output_dir=cfg.output_dir,
        num_train_epochs=cfg.num_train_epochs,
        per_device_train_batch_size=cfg.per_device_train_batch_size,
        gradient_accumulation_steps=cfg.gradient_accumulation_steps,
        learning_rate=cfg.learning_rate,
        lr_scheduler_type=cfg.lr_scheduler_type,
        warmup_ratio=cfg.warmup_ratio,
        bf16=cfg.bf16,
        logging_steps=cfg.logging_steps,
        save_steps=cfg.save_steps,
        save_total_limit=cfg.save_total_limit,
        beta=cfg.beta,
        max_prompt_length=cfg.max_prompt_length,
        max_length=cfg.max_length,
        report_to=cfg.report_to,
    )

    trainer = DPOTrainer(
        model=model,
        ref_model=None,        # None = use implicit reference via LoRA merge
        args=training_args,
        train_dataset=hf_ds,
        tokenizer=tokenizer,
    )

    trainer.train()
    trainer.save_model(cfg.output_dir)
    print("\n[Phase 3] ✓ Done.")
    return model


# ─────────────────────────────────────────────────────────────────────
# Top-level YetiTrainer
# ─────────────────────────────────────────────────────────────────────

class YetiTrainer:
    """Orchestrates all three training phases."""

    def __init__(self, model, tokenizer, train_cfg, data_loader_factory):
        self.model      = model
        self.tokenizer  = tokenizer
        self.cfg        = train_cfg
        self.loader_fac = data_loader_factory
        self.device     = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def run_all(self, phases=(1, 2, 3)):
        if 1 in phases:
            loader = self.loader_fac.get_pretrain_loader(self.cfg.phase1)
            self.model = run_phase1(self.model, loader, self.cfg.phase1, self.device)

        if 2 in phases:
            loader = self.loader_fac.get_sft_loader(self.cfg.phase2)
            self.model = run_phase2(self.model, loader, self.cfg.phase2, self.device)

        if 3 in phases:
            dpo_ds = self.loader_fac.get_dpo_loader(self.cfg.phase3).dataset
            self.model = run_phase3(
                self.model, self.tokenizer, dpo_ds, self.cfg.phase3, self.device
            )

        print("\n🎉 All training phases complete!")
        return self.model
