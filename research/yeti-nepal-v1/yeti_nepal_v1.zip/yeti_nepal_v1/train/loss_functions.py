"""
Loss Functions for Yeti Nepal v1
==================================
  - Cross-entropy language model loss
  - MoE load-balance loss (Switch Transformers)
  - Router z-loss (ST-MoE stability)
  - Combined YetiLoss wrapper
"""

import torch
import torch.nn.functional as F
from typing import List, Optional


# ─────────────────────────────────────────────────────────────────────
# MoE Load-Balance Loss  (Switch Transformers §4)
# ─────────────────────────────────────────────────────────────────────

def compute_moe_aux_loss(
    router_logits: torch.Tensor,        # [B, T, num_experts]
    num_experts: int,
    alpha: float = 0.01,
) -> torch.Tensor:
    """
    Encourages equal load across experts.

    L_aux = alpha * N * sum_i( f_i * P_i )

    where f_i = fraction of tokens routed to expert i,
          P_i = mean router softmax probability for expert i.
    """
    # probs: [B*T, E]
    probs = F.softmax(router_logits.float(), dim=-1)
    probs_flat = probs.reshape(-1, num_experts)          # [B*T, E]

    # f_i: mean fraction of tokens routed to expert i
    expert_mask = torch.zeros_like(probs_flat)
    top1 = probs_flat.argmax(dim=-1)                     # [B*T]
    expert_mask.scatter_(1, top1.unsqueeze(1), 1.0)
    f_i = expert_mask.mean(dim=0)                        # [E]

    # P_i: mean softmax weight for expert i
    P_i = probs_flat.mean(dim=0)                         # [E]

    loss = alpha * num_experts * (f_i * P_i).sum()
    return loss


def compute_moe_aux_loss_all_layers(
    all_router_logits: List[torch.Tensor],
    num_experts: int,
    alpha: float = 0.01,
) -> torch.Tensor:
    """Aggregate aux loss over all MoE layers."""
    if not all_router_logits:
        return torch.tensor(0.0, device="cpu")   # will be moved to correct device by caller
    losses = [compute_moe_aux_loss(rl, num_experts, alpha) for rl in all_router_logits]
    return torch.stack(losses).mean()


# ─────────────────────────────────────────────────────────────────────
# Router Z-Loss  (ST-MoE §2.3)
# ─────────────────────────────────────────────────────────────────────

def compute_router_z_loss(
    router_logits: torch.Tensor,        # [B, T, num_experts]
    z_coeff: float = 0.001,
) -> torch.Tensor:
    """
    Penalises large router logits to prevent numerical instability.

    L_z = c_z * mean_x( log(sum_i exp(h_i(x))) )^2
    """
    log_sum_exp = torch.logsumexp(router_logits.float(), dim=-1)  # [B, T]
    z_loss = z_coeff * log_sum_exp.pow(2).mean()
    return z_loss


def compute_router_z_loss_all_layers(
    all_router_logits: List[torch.Tensor],
    z_coeff: float = 0.001,
) -> torch.Tensor:
    if not all_router_logits:
        return torch.tensor(0.0, device="cpu")
    losses = [compute_router_z_loss(rl, z_coeff) for rl in all_router_logits]
    return torch.stack(losses).mean()


# ─────────────────────────────────────────────────────────────────────
# Combined Loss
# ─────────────────────────────────────────────────────────────────────

class YetiLoss:
    """
    Combines:
      loss_total = loss_ce + loss_moe_balance + loss_router_z

    Usage:
        yeti_loss = YetiLoss(config)
        loss, breakdown = yeti_loss(model, lm_loss)
    """

    def __init__(self, config):
        self.num_experts  = config.num_experts
        self.balance_coeff = config.balance_loss_coeff
        self.z_coeff       = config.z_loss_coeff

    def __call__(
        self,
        model,                           # YetiForCausalLM or YetiModel
        ce_loss: torch.Tensor,
    ):
        # Accept both YetiForCausalLM (has .model sub-module) and bare YetiModel
        yeti_model = model.model if hasattr(model, "model") and hasattr(model.model, "get_all_router_logits") else model
        all_router_logits = yeti_model.get_all_router_logits()

        # Move zero tensors to the same device as ce_loss to avoid CUDA/CPU mismatch
        dev = ce_loss.device
        loss_balance = compute_moe_aux_loss_all_layers(
            all_router_logits, self.num_experts, self.balance_coeff
        ).to(dev)
        loss_z = compute_router_z_loss_all_layers(
            all_router_logits, self.z_coeff
        ).to(dev)

        total = ce_loss + loss_balance + loss_z

        breakdown = {
            "loss_ce":      ce_loss.item(),
            "loss_balance": loss_balance.item(),
            "loss_z":       loss_z.item(),
            "loss_total":   total.item(),
        }
        return total, breakdown
