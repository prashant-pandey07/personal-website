# Yeti Nepal v1-500M

A hybrid **480–510M parameter** causal language model combining Mamba-2 SSM, Grouped-Query Attention (GQA), and a 2-Expert Mixture-of-Experts (MoE) — designed to train on a **free Google Colab T4 (16 GB VRAM)**.

---

## Architecture

| Component | Details |
|---|---|
| Total layers | 24 (18 Mamba-2 SSM + 6 GQA, every 4th) |
| Hidden size | 1024 |
| SSM state dim | 64 |
| Attention heads | 8 Q / 2 KV (GQA 4:1 ratio) |
| Experts per layer | 2 SwiGLU (Top-1 inference, Top-2 training) |
| FFN width | 2048 |
| Vocab | 32 000 (LLaMA-compatible BPE) |
| Max seq len | 4096 |
| ~Parameters | **483 M** |

---

## Project Structure

```
yeti_nepal_v1/
├── config/
│   ├── model_config.py      # Architecture hyperparams + presets
│   └── train_config.py      # Phase 1/2/3 training hyperparams
├── model/
│   ├── mamba_block.py       # Mamba-2 SSM layer (pure PyTorch)
│   ├── attention_block.py   # GQA + RoPE (FlashAttn via SDPA)
│   ├── moe_layer.py         # 2-expert MoE + Top-1/Top-2 router
│   └── yeti_core.py         # Full model + causal LM head
├── data/
│   ├── processor.py         # Text cleaning, tokenisation, CoT formatting
│   └── loader.py            # Streaming DataLoaders for all 3 phases
├── train/
│   ├── loss_functions.py    # CE + MoE load-balance + router z-loss
│   └── trainer.py           # Phase 1/2/3 training loops + DPO
├── evaluate.py              # Perplexity, accuracy, generation eval
├── export_gguf.py           # Export → safetensors → GGUF (llama.cpp)
├── run_colab.py             # ← MAIN FILE: paste each cell into Colab
└── requirements.txt
```

---

## Quick Start (Colab)

### 1. Upload to Colab

Upload the entire `yeti_nepal_v1/` folder to `/content/` via the Colab file panel, or mount Google Drive:

```python
from google.colab import drive
drive.mount('/content/drive')
```

### 2. Open `run_colab.py`

Copy each `# CELL N` section into its own Colab code cell. Run them **top to bottom**.

### 3. First run: use debug mode

In **Cell 4**, set:
```python
SCALE = "debug"    # ~20M params, sanity check
```

Once the pipeline runs end-to-end, switch to:
```python
SCALE = "full"     # ~483M params, real training
```

---

## Training Phases

| Phase | Data | Tokens | Goal |
|---|---|---|---|
| **1 — Pretrain** | FineWeb-Edu | 20B | Factual knowledge |
| **2 — SFT** | OpenHermes-2.5 + Dolphin CoT | 5B | Instruction + reasoning |
| **3 — DPO** | UltraFeedback | 20K pairs | Alignment |

---

## Checkpointing & Resuming

Checkpoints are saved every N steps to `./checkpoints/phase1/`. To resume:

```python
RESUME_FROM = "./checkpoints/phase1/ckpt_step500.pt"
model = run_phase1(model, pretrain_loader, train_cfg.phase1, DEVICE,
                   resume_from=RESUME_FROM)
```

---

## Evaluation

```bash
python evaluate.py --checkpoint ./checkpoints/phase2_final_step1000.pt
```

Expected targets after full training:
- **GSM8K** ≥ 70%
- **TruthfulQA** improved over baseline
- **Perplexity** < 20 on held-out web text

---

## GGUF Export (llama.cpp)

After training, export for CPU inference:

```bash
python export_gguf.py \
    --checkpoint ./checkpoints/phase2_final_step1000.pt \
    --output_dir ./gguf_export \
    --quant Q4_K_M
```

Run with llama.cpp:
```bash
./llama-cli -m ./gguf_export/yeti-Q4_K_M.gguf -n 256 \
    -p "<|user|>\nWhat is machine learning?\n<|assistant|>\n"
```

---

## Roadmap

```
Jun 2026 — 50M debug build  ✓
Aug 2026 — 120M scale
Oct 2026 — 300M scale
Dec 2026 — 500M full model
```

---

## Key Design Decisions

- **Safety deferred to Phase 2+**: First build focuses on capability. Constitutional AI / safety finetuning added after first successful run.
- **No mamba-ssm dependency**: Pure PyTorch SSM scan; drop-in replaced by CUDA kernel if `mamba-ssm` is installed.
- **Unsloth optional**: Falls back gracefully if Unsloth can't attach to a custom architecture.
- **Progressive scaling**: Always validate the pipeline at debug scale before committing to full training runs.
