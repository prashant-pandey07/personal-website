"""
Mamba-2 SSM Block — Pure PyTorch Implementation
=================================================
Implements the selective state-space (SSM) layer used in 80% of
Yeti Nepal v1 layers.  This is a faithful adaptation of Mamba-2
that runs on any CUDA or CPU device without the mamba-ssm C extension.

If the `mamba_ssm` package is installed, we call its optimised CUDA
kernel instead (3–5× faster).  The interface is identical.

References:
  Dao & Gu, "Transformers are SSMs" (Mamba-2), 2024.
  Gu & Dao, "Mamba: Linear-Time Sequence Modeling", 2023.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat

try:
    from mamba_ssm import Mamba2  # fast CUDA path
    _MAMBA_CUDA = True
except ImportError:
    _MAMBA_CUDA = False


# ─────────────────────────────────────────────────────────────────────
# Helper: RMS Normalisation
# ─────────────────────────────────────────────────────────────────────

class RMSNorm(nn.Module):
    """Root-mean-square layer normalisation (no centering bias)."""

    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rms = x.pow(2).mean(-1, keepdim=True).add(self.eps).rsqrt()
        return x * rms * self.weight


# ─────────────────────────────────────────────────────────────────────
# Pure-PyTorch selective scan (fallback when mamba_ssm not available)
# ─────────────────────────────────────────────────────────────────────

def selective_scan_torch(
    u: torch.Tensor,          # [B, L, d_inner]
    delta: torch.Tensor,      # [B, L, d_inner]  (after softplus + dt_proj)
    A: torch.Tensor,          # [d_inner, d_state] — log-parameterised
    B: torch.Tensor,          # [B, L, d_state]
    C: torch.Tensor,          # [B, L, d_state]
    D: torch.Tensor,          # [d_inner]          — skip connection
) -> torch.Tensor:
    """
    Sequential selective SSM scan.
    y_t = C @ h_t  where  h_t = dA * h_{t-1} + dB * u_t
    """
    B_batch, L, d_inner = u.shape
    d_state = A.shape[-1]

    # Discretise A and B using Zero-Order Hold (ZOH)
    # dA[b,t,d,n] = exp( delta[b,t,d] * A[d,n] )
    dA = torch.exp(
        torch.einsum("bld,dn->bldn", delta, A)
    )  # [B, L, d_inner, d_state]

    # dB[b,t,d,n] = delta[b,t,d] * B[b,t,n] * u[b,t,d]
    dB_u = torch.einsum("bld,bln,bld->bldn", delta, B, u)
    # [B, L, d_inner, d_state]

    # Sequential scan over time dimension
    h = torch.zeros(B_batch, d_inner, d_state, device=u.device, dtype=u.dtype)
    ys = []
    for t in range(L):
        h = dA[:, t] * h + dB_u[:, t]              # [B, d_inner, d_state]
        y_t = torch.einsum("bdn,bn->bd", h, C[:, t])  # [B, d_inner]
        ys.append(y_t)

    y = torch.stack(ys, dim=1)   # [B, L, d_inner]
    y = y + D.unsqueeze(0).unsqueeze(0) * u         # skip connection
    return y


# ─────────────────────────────────────────────────────────────────────
# Mamba-2 Block
# ─────────────────────────────────────────────────────────────────────

class MambaBlock(nn.Module):
    """
    One Mamba-2 SSM layer.

    Data flow:
        x  →  [RMSNorm]  →  in_proj  →  (z, x')
        x' →  conv1d  →  x_proj  →  (dt, B, C)
        SSM scan  →  gate(z)  →  out_proj  →  residual add

    Args:
        config: YetiModelConfig instance
    """

    def __init__(self, config):
        super().__init__()

        d_model  = config.hidden_size
        d_inner  = config.ssm_d_inner          # hidden_size * expand
        d_state  = config.ssm_state_dim
        dt_rank  = config.dt_rank
        conv_w   = config.ssm_conv_width

        self.d_inner = d_inner
        self.d_state = d_state
        self.dt_rank = dt_rank

        # ── Norms ─────────────────────────────────────────────────
        self.norm = RMSNorm(d_model, config.rms_norm_eps)

        # ── Input projection: d_model → 2 * d_inner (z and x) ────
        self.in_proj = nn.Linear(d_model, d_inner * 2, bias=False)

        # ── Depthwise causal conv1d on x ──────────────────────────
        self.conv1d = nn.Conv1d(
            in_channels=d_inner,
            out_channels=d_inner,
            kernel_size=conv_w,
            groups=d_inner,
            padding=conv_w - 1,   # causal: pad left
            bias=True,
        )

        # ── SSM projections: x → (dt, B, C) ──────────────────────
        self.x_proj = nn.Linear(d_inner, dt_rank + d_state * 2, bias=False)

        # ── Delta projection: dt_rank → d_inner ───────────────────
        self.dt_proj = nn.Linear(dt_rank, d_inner, bias=True)

        # ── A matrix (log-parameterised for stability) ────────────
        # Initialise A_log so A = -exp(A_log) is always negative
        A = repeat(
            torch.arange(1, d_state + 1, dtype=torch.float32),
            "n -> d n",
            d=d_inner,
        )
        self.A_log = nn.Parameter(torch.log(A))
        self.A_log._no_weight_decay = True  # type: ignore

        # ── D skip-connection ─────────────────────────────────────
        self.D = nn.Parameter(torch.ones(d_inner))
        self.D._no_weight_decay = True  # type: ignore

        # ── Output projection: d_inner → d_model ─────────────────
        self.out_proj = nn.Linear(d_inner, d_model, bias=False)

        # ── Initialise dt_proj bias for good dt range ─────────────
        dt_init_std = dt_rank ** -0.5 * config.ssm_dt_scale
        nn.init.uniform_(self.dt_proj.weight, -dt_init_std, dt_init_std)
        dt = torch.exp(
            torch.rand(d_inner) * (
                math.log(config.ssm_dt_max) - math.log(config.ssm_dt_min)
            ) + math.log(config.ssm_dt_min)
        ).clamp(min=config.ssm_dt_init_floor)
        inv_dt = dt + torch.log(-torch.expm1(-dt))   # soft-plus inverse
        with torch.no_grad():
            self.dt_proj.bias.copy_(inv_dt)
        self.dt_proj.bias._no_weight_decay = True  # type: ignore

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """
        Args:
            hidden_states: [batch, seq_len, d_model]
        Returns:
            output: [batch, seq_len, d_model]
        """
        residual = hidden_states
        hidden_states = self.norm(hidden_states)

        B, L, _ = hidden_states.shape

        # ── Input projection ──────────────────────────────────────
        xz = self.in_proj(hidden_states)            # [B, L, 2*d_inner]
        x, z = xz.chunk(2, dim=-1)                  # each [B, L, d_inner]

        # ── Causal conv1d on x ───────────────────────────────────
        x_t = x.transpose(1, 2)                      # [B, d_inner, L]
        x_t = self.conv1d(x_t)[..., :L]              # trim causal padding
        x   = F.silu(x_t.transpose(1, 2))            # [B, L, d_inner]

        # ── SSM projections ───────────────────────────────────────
        xbc = self.x_proj(x)   # [B, L, dt_rank + 2*d_state]
        dt, B_mat, C_mat = torch.split(
            xbc, [self.dt_rank, self.d_state, self.d_state], dim=-1
        )
        dt = F.softplus(self.dt_proj(dt))            # [B, L, d_inner]

        # A = -exp(A_log)  →  always negative (stable)
        A = -torch.exp(self.A_log.float())           # [d_inner, d_state]

        # ── Selective scan ────────────────────────────────────────
        y = selective_scan_torch(
            u=x.float(), delta=dt.float(),
            A=A, B=B_mat.float(), C=C_mat.float(), D=self.D.float()
        ).to(hidden_states.dtype)

        # ── Gate and output ───────────────────────────────────────
        y = y * F.silu(z)                            # [B, L, d_inner]
        output = self.out_proj(y)                    # [B, L, d_model]

        return output + residual                     # residual connection
