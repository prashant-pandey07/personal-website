"""
Yeti Core — Full Model Assembly
=================================
Stacks Mamba-2 SSM + GQA Attention + MoE layers into the complete
Yeti Nepal v1 causal language model.
"""

import torch
import torch.nn as nn
import torch.utils.checkpoint
from typing import Optional, Tuple, List

from .mamba_block import MambaBlock, RMSNorm
from .attention_block import GQAAttention
from .moe_layer import MoELayer


class YetiLayer(nn.Module):
    """One hybrid layer: SSM or GQA attention, followed by MoE FFN."""

    def __init__(self, config, layer_idx: int):
        super().__init__()
        self.layer_idx = layer_idx
        self.use_attention = (layer_idx % config.attention_every_n == 0)

        if self.use_attention:
            self.mixer = GQAAttention(config)
        else:
            self.mixer = MambaBlock(config)

        self.moe = MoELayer(config)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[Tuple] = None,
        use_cache: bool = False,
    ):
        new_kv = None
        if self.use_attention:
            hidden_states, new_kv = self.mixer(
                hidden_states,
                attention_mask=attention_mask,
                past_key_value=past_key_value,
                use_cache=use_cache,
            )
        else:
            hidden_states = self.mixer(hidden_states)

        hidden_states = self.moe(hidden_states)
        return hidden_states, new_kv


class YetiModel(nn.Module):
    """
    Yeti Nepal v1 backbone (no LM head).
    Embedding → N × YetiLayer → Final RMSNorm
    """

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.gradient_checkpointing = False

        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)
        self.layers = nn.ModuleList([
            YetiLayer(config, i) for i in range(config.num_layers)
        ])
        self.norm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.dropout = nn.Dropout(config.dropout) if config.dropout > 0 else nn.Identity()

        self.apply(self._init_weights)

    def enable_gradient_checkpointing(self):
        """Trade compute for memory: recompute activations on backward pass."""
        self.gradient_checkpointing = True
        print("[YetiModel] Gradient checkpointing enabled.")

    def disable_gradient_checkpointing(self):
        self.gradient_checkpointing = False

    def _init_weights(self, module):
        std = 0.02
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, std=std)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, std=std)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[List[Tuple]] = None,
        use_cache: bool = False,
    ):
        hidden_states = self.dropout(self.embed_tokens(input_ids))
        new_kv_cache = [] if use_cache else None

        for i, layer in enumerate(self.layers):
            past_kv = past_key_values[i] if past_key_values else None

            if self.gradient_checkpointing and self.training and not use_cache:
                # Gradient checkpointing: wrap layer call so activations are
                # recomputed on backward instead of stored in memory.
                def create_custom_forward(l):
                    def custom_forward(*inputs):
                        hs, new_kv = l(inputs[0], attention_mask=inputs[1],
                                       past_key_value=None, use_cache=False)
                        return hs, torch.tensor(0)  # dummy for new_kv
                    return custom_forward

                hidden_states, _ = torch.utils.checkpoint.checkpoint(
                    create_custom_forward(layer),
                    hidden_states,
                    attention_mask if attention_mask is not None
                    else torch.zeros(1, device=hidden_states.device),
                    use_reentrant=False,
                )
                new_kv = None
            else:
                hidden_states, new_kv = layer(
                    hidden_states,
                    attention_mask=attention_mask,
                    past_key_value=past_kv,
                    use_cache=use_cache,
                )

            if use_cache:
                new_kv_cache.append(new_kv)

        hidden_states = self.norm(hidden_states)
        return hidden_states, new_kv_cache

    def get_all_router_logits(self) -> List[torch.Tensor]:
        """Collect router logits from all MoE layers for aux loss."""
        logits = []
        for layer in self.layers:
            rl = layer.moe.get_router_logits()
            if rl is not None:
                logits.append(rl)
        return logits

    def get_all_expert_indices(self) -> List[torch.Tensor]:
        indices = []
        for layer in self.layers:
            ei = layer.moe.get_expert_indices()
            if ei is not None:
                indices.append(ei)
        return indices


class YetiForCausalLM(nn.Module):
    """
    Yeti Nepal v1 with causal LM head for autoregressive training/inference.
    """

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.model = YetiModel(config)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        if config.tie_word_embeddings:
            self.lm_head.weight = self.model.embed_tokens.weight

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        past_key_values: Optional[List[Tuple]] = None,
        use_cache: bool = False,
    ):
        hidden_states, new_kv_cache = self.model(
            input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            use_cache=use_cache,
        )
        logits = self.lm_head(hidden_states)

        loss = None
        if labels is not None:
            shift_logits = logits[:, :-1, :].contiguous()
            shift_labels = labels[:, 1:].contiguous()
            loss = nn.functional.cross_entropy(
                shift_logits.view(-1, self.config.vocab_size),
                shift_labels.view(-1),
                ignore_index=-100,
            )

        return {
            "loss": loss,
            "logits": logits,
            "past_key_values": new_kv_cache,
        }

    def generate_simple(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 256,
        temperature: float = 0.7,
        top_k: int = 50,
        top_p: float = 0.9,
        eos_token_id: int = 2,
    ) -> torch.Tensor:
        """Simple autoregressive generation with KV cache."""
        self.eval()
        past_kv = None
        generated = input_ids

        with torch.no_grad():
            for _ in range(max_new_tokens):
                out = self.forward(
                    input_ids=generated if past_kv is None else generated[:, -1:],
                    past_key_values=past_kv,
                    use_cache=True,
                )
                past_kv = out["past_key_values"]
                next_logits = out["logits"][:, -1, :] / temperature

                # Top-k filtering
                if top_k > 0:
                    v, _ = torch.topk(next_logits, min(top_k, next_logits.size(-1)))
                    next_logits[next_logits < v[:, [-1]]] = float("-inf")

                # Top-p (nucleus) filtering
                if top_p < 1.0:
                    sorted_logits, sorted_idx = torch.sort(next_logits, descending=True)
                    cumulative = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
                    remove = cumulative - torch.softmax(sorted_logits, dim=-1) >= top_p
                    sorted_logits[remove] = float("-inf")
                    next_logits = sorted_logits.scatter(1, sorted_idx, sorted_logits)

                probs = torch.softmax(next_logits, dim=-1)
                next_token = torch.multinomial(probs, num_samples=1)
                generated = torch.cat([generated, next_token], dim=1)

                if next_token.item() == eos_token_id:
                    break

        return generated

    def count_parameters(self) -> dict:
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return {
            "total_M": round(total / 1e6, 2),
            "trainable_M": round(trainable / 1e6, 2),
        }
