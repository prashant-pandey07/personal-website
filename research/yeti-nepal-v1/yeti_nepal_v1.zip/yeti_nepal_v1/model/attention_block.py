"""
Grouped-Query Attention (GQA) Block
=====================================
Used in every attention_every_n-th layer of Yeti Nepal v1.
GQA reduces KV-cache memory by sharing Key/Value heads across
groups of Query heads (here 4 Q-heads per KV-head pair).

Includes:
  - RoPE (Rotary Position Embeddings) for relative position encoding
  - Sliding-window masking (optional, for very long contexts)
  - Flash-Attention 2 via torch.nn.functional.scaled_dot_product_attention

References:
  Ainslie et al., "GQA: Training Generalised Multi-Query Transformer
      Models from Multi-Head Checkpoints", 2023.
  Su et al., "RoFormer: Enhanced Transformer with Rotary Position
      Embedding", 2021.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple

from .mamba_block import RMSNorm


# ─────────────────────────────────────────────────────────────────────
# Rotary Position Embedding (RoPE)
# ─────────────────────────────────────────────────────────────────────

class RotaryEmbedding(nn.Module):
    """
    Pre-computes sin/cos rotation tables up to max_seq_len.
    Applied to the first `dim` features of each head.
    """

    def __init__(self, dim: int, max_seq_len: int = 4096, theta: float = 10_000.0):
        super().__init__()
        inv_freq = 1.0 / (theta ** (
            torch.arange(0, dim, 2, dtype=torch.float32) / dim
        ))
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self._build_cache(max_seq_len)

    def _build_cache(self, max_seq_len: int):
        t   = torch.arange(max_seq_len, device=self.inv_freq.device, dtype=self.inv_freq.dtype)
        freqs = torch.outer(t, self.inv_freq)          # [L, dim/2]
        emb   = torch.cat([freqs, freqs], dim=-1)      # [L, dim]
        self.register_buffer("cos_cached", emb.cos(), persistent=False)
        self.register_buffer("sin_cached", emb.sin(), persistent=False)

    def forward(self, seq_len: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return (
            self.cos_cached[:seq_len],   # [seq_len, dim]
            self.sin_cached[:seq_len],
        )


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Split last dim in half and rotate."""
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat([-x2, x1], dim=-1)


def apply_rotary_emb(
    q: torch.Tensor,
    k: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Apply RoPE to Q and K tensors (shape [B, heads, L, head_dim])."""
    cos = cos[None, None, :, :]     # [1, 1, L, head_dim]
    sin = sin[None, None, :, :]
    q_rot = q * cos + rotate_half(q) * sin
    k_rot = k * cos + rotate_half(k) * sin
    return q_rot, k_rot


# ─────────────────────────────────────────────────────────────────────
# GQA Attention
# ─────────────────────────────────────────────────────────────────────

class GQAAttention(nn.Module):
    """
    Grouped-Query Attention with RoPE and causal mask.

    - num_heads query heads share num_kv_heads K/V heads.
    - Groups of (num_heads // num_kv_heads) queries share one K/V pair.
    - Uses PyTorch 2.x scaled_dot_product_attention (FlashAttn2 when available).

    Args:
        config: YetiModelConfig instance
    """

    def __init__(self, config):
        super().__init__()

        self.d_model      = config.hidden_size
        self.num_heads    = config.num_attention_heads
        self.num_kv_heads = config.num_kv_heads
        self.head_dim     = config.head_dim
        self.kv_groups    = self.num_heads // self.num_kv_heads   # Q heads per KV

        assert self.num_heads % self.num_kv_heads == 0

        # ── Norms ─────────────────────────────────────────────────
        self.norm = RMSNorm(self.d_model, config.rms_norm_eps)

        # ── Projections ───────────────────────────────────────────
        self.q_proj = nn.Linear(self.d_model, self.num_heads    * self.head_dim, bias=False)
        self.k_proj = nn.Linear(self.d_model, self.num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(self.d_model, self.num_kv_heads * self.head_dim, bias=False)
        self.o_proj = nn.Linear(self.num_heads * self.head_dim, self.d_model,    bias=False)

        self.attn_dropout = config.attention_dropout

        # ── RoPE ──────────────────────────────────────────────────
        self.rotary_emb = RotaryEmbedding(
            dim=self.head_dim,
            max_seq_len=config.max_position_embeddings,
            theta=config.rope_theta,
        )

        # ── Initialise weights ────────────────────────────────────
        self._init_weights()

    def _init_weights(self):
        std = self.d_model ** -0.5
        for proj in [self.q_proj, self.k_proj, self.v_proj, self.o_proj]:
            nn.init.normal_(proj.weight, std=std)

    def _expand_kv(self, kv: torch.Tensor) -> torch.Tensor:
        """
        Repeat K or V heads to match Q heads.
        Input:  [B, num_kv_heads, L, head_dim]
        Output: [B, num_heads, L, head_dim]
        """
        return kv.repeat_interleave(self.kv_groups, dim=1)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        use_cache: bool = False,
    ) -> Tuple[torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]]:
        """
        Args:
            hidden_states: [B, L, d_model]
            attention_mask: optional boolean mask [B, 1, L, L]
            past_key_value: KV cache for generation (K, V each [B, kv_heads, past_L, head_dim])
            use_cache: whether to return updated KV cache

        Returns:
            output: [B, L, d_model]
            past_key_value: updated cache (or None)
        """
        residual      = hidden_states
        hidden_states = self.norm(hidden_states)

        B, L, _ = hidden_states.shape

        # ── Q, K, V projections ───────────────────────────────────
        Q = self.q_proj(hidden_states).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        K = self.k_proj(hidden_states).view(B, L, self.num_kv_heads, self.head_dim).transpose(1, 2)
        V = self.v_proj(hidden_states).view(B, L, self.num_kv_heads, self.head_dim).transpose(1, 2)
        # Q: [B, num_heads, L, head_dim]
        # K: [B, num_kv_heads, L, head_dim]
        # V: [B, num_kv_heads, L, head_dim]

        # ── RoPE ──────────────────────────────────────────────────
        cos, sin = self.rotary_emb(L + (past_key_value[0].shape[2] if past_key_value else 0))
        if past_key_value:
            past_len = past_key_value[0].shape[2]
            cos, sin = cos[past_len:], sin[past_len:]
        Q, K = apply_rotary_emb(Q, K, cos, sin)

        # ── KV Cache ──────────────────────────────────────────────
        if past_key_value is not None:
            K = torch.cat([past_key_value[0], K], dim=2)
            V = torch.cat([past_key_value[1], V], dim=2)
        new_kv_cache = (K, V) if use_cache else None

        # ── Expand KV to match Q heads (GQA) ─────────────────────
        K_expanded = self._expand_kv(K)   # [B, num_heads, L, head_dim]
        V_expanded = self._expand_kv(V)

        # ── Scaled dot-product attention (uses FlashAttn2 if avail) ─
        # is_causal=True automatically builds the causal mask.
        attn_output = F.scaled_dot_product_attention(
            Q, K_expanded, V_expanded,
            attn_mask=attention_mask,
            dropout_p=self.attn_dropout if self.training else 0.0,
            is_causal=(attention_mask is None),   # causal unless mask provided
        )
        # attn_output: [B, num_heads, L, head_dim]

        # ── Output projection ─────────────────────────────────────
        attn_output = attn_output.transpose(1, 2).contiguous().view(B, L, -1)
        output      = self.o_proj(attn_output)

        return output + residual, new_kv_cache
