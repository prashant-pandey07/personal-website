"""
Mixture-of-Experts Layer
========================
2-Expert Top-1/Top-2 Router with SwiGLU experts.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional
from .mamba_block import RMSNorm


class SwiGLUExpert(nn.Module):
    """SwiGLU FFN: down_proj(silu(gate(x)) * up(x))"""
    def __init__(self, hidden_size: int, ffn_hidden_size: int):
        super().__init__()
        self.gate_proj = nn.Linear(hidden_size, ffn_hidden_size, bias=False)
        self.up_proj   = nn.Linear(hidden_size, ffn_hidden_size, bias=False)
        self.down_proj = nn.Linear(ffn_hidden_size, hidden_size, bias=False)

    def forward(self, x):
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class Top1Router(nn.Module):
    """Learned gate: routes each token to 1 of N experts."""
    def __init__(self, hidden_size: int, num_experts: int = 2):
        super().__init__()
        self.gate = nn.Linear(hidden_size, num_experts, bias=False)

    def forward(self, hidden_states):
        logits = self.gate(hidden_states)
        probs  = F.softmax(logits, dim=-1)
        top1_weights, top1_indices = probs.max(dim=-1)
        return top1_indices, top1_weights, logits


class MoELayer(nn.Module):
    """
    2-expert MoE. Top-2 during training, Top-1 at inference.
    Exposes router_logits for auxiliary loss computation.
    """
    def __init__(self, config):
        super().__init__()
        self.num_experts = config.num_experts
        self.norm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.router = Top1Router(config.hidden_size, config.num_experts)
        self.experts = nn.ModuleList([
            SwiGLUExpert(config.hidden_size, config.ffn_hidden_size)
            for _ in range(config.num_experts)
        ])
        self._last_router_logits = None
        self._last_expert_indices = None

    def forward(self, hidden_states):
        residual = hidden_states
        hidden_states = self.norm(hidden_states)
        B, T, H = hidden_states.shape
        expert_indices, expert_weights, router_logits = self.router(hidden_states)
        self._last_router_logits = router_logits
        self._last_expert_indices = expert_indices

        if self.training and self.num_experts > 1:
            output = self._top2_forward(hidden_states, router_logits)
        else:
            output = self._top1_forward(hidden_states, expert_indices, expert_weights)
        return output + residual

    def _top1_forward(self, hidden_states, expert_indices, expert_weights):
        B, T, H = hidden_states.shape
        output = torch.zeros_like(hidden_states)
        flat_states  = hidden_states.reshape(-1, H)
        flat_indices = expert_indices.reshape(-1)
        flat_weights = expert_weights.reshape(-1, 1)
        for idx, expert in enumerate(self.experts):
            mask = (flat_indices == idx)
            if mask.any():
                out = expert(flat_states[mask]) * flat_weights[mask]
                output.view(-1, H)[mask] = out
        return output

    def _top2_forward(self, hidden_states, router_logits):
        B, T, H = hidden_states.shape
        probs = F.softmax(router_logits, dim=-1)
        top2_weights, top2_indices = probs.topk(2, dim=-1)
        top2_weights = top2_weights / (top2_weights.sum(-1, keepdim=True) + 1e-9)
        flat_states = hidden_states.reshape(-1, H)
        output = torch.zeros_like(flat_states)
        for k in range(2):
            indices_k = top2_indices[:, :, k].reshape(-1)
            weights_k = top2_weights[:, :, k].reshape(-1, 1)
            for idx, expert in enumerate(self.experts):
                mask = (indices_k == idx)
                if mask.any():
                    output[mask] += expert(flat_states[mask]) * weights_k[mask]
        return output.view(B, T, H)

    def get_router_logits(self):
        return self._last_router_logits

    def get_expert_indices(self):
        return self._last_expert_indices
