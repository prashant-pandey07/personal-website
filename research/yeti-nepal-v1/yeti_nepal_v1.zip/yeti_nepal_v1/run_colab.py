"""
╔══════════════════════════════════════════════════════════════════╗
║      YETI NEPAL v1-500M — MASTER COLAB TRAINING SCRIPT          ║
║      Copy each # CELL section into its own Colab code cell.     ║
║      Runtime: GPU → T4 (16 GB VRAM)  ·  Python ≥ 3.10          ║
╚══════════════════════════════════════════════════════════════════╝

QUICK START
-----------
1. Set Runtime → Change runtime type → T4 GPU
2. Run CELL 1 (installs deps) → restart runtime when prompted
3. Run CELL 2 (upload project)
4. Run CELL 3 → CELL 12 in order
5. First run: keep SCALE = "debug" to validate the full pipeline fast
"""


# ══════════════════════════════════════════════════════════════════
# CELL 1 — Install dependencies
# (Run once, then restart runtime when Colab asks)
# ══════════════════════════════════════════════════════════════════

import subprocess, sys

def pip(*args):
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", *args], check=True)

# Core ML stack
pip("torch>=2.2", "torchvision", "--index-url", "https://download.pytorch.org/whl/cu121")
pip(
    "transformers>=4.40.0",
    "datasets>=2.19.0",
    "accelerate>=0.28.0",
    "tokenizers>=0.19.0",
    "safetensors>=0.4.3",
    "huggingface_hub>=0.22.0",
)
pip("trl>=0.8.6", "peft>=0.10.0", "einops>=0.7.0")

# Flash-Attention 2 (optional — speeds up GQA layers on T4 Ampere)
try:
    pip("flash-attn", "--no-build-isolation")
    print("✓ Flash-Attention 2 installed")
except Exception:
    print("ℹ Flash-Attention skipped (not critical, falls back to SDPA)")

print("\n✓ All packages installed. If prompted → Restart Runtime → then continue from CELL 2.")


# ══════════════════════════════════════════════════════════════════
# CELL 2 — Upload project & verify
# ══════════════════════════════════════════════════════════════════
# Option A (recommended): Zip the yeti_nepal_v1/ folder, upload it
#   here, then run the unzip line below.
# Option B: Mount Google Drive
#   from google.colab import drive; drive.mount('/content/drive')
#   import shutil
#   shutil.copytree('/content/drive/MyDrive/yeti_nepal_v1', '/content/yeti_nepal_v1')

import os, sys

# ── If you uploaded a zip, unzip it: ──────────────────────────────
# import zipfile
# with zipfile.ZipFile('/content/yeti_nepal_v1.zip') as z:
#     z.extractall('/content/')

PROJECT_DIR = "/content/yeti_nepal_v1"
if not os.path.isdir(PROJECT_DIR):
    raise FileNotFoundError(
        "\n✗ yeti_nepal_v1/ not found at /content/.\n"
        "  → Upload the folder (or a zip of it) via the Colab file panel,\n"
        "    or mount your Google Drive."
    )

# Make the project importable
if "/content" not in sys.path:
    sys.path.insert(0, "/content")

# Quick structure check
required = [
    "config/model_config.py", "config/train_config.py",
    "model/yeti_core.py", "model/mamba_block.py",
    "model/attention_block.py", "model/moe_layer.py",
    "data/processor.py", "data/loader.py",
    "train/trainer.py", "train/loss_functions.py",
]
missing = [f for f in required if not os.path.exists(os.path.join(PROJECT_DIR, f))]
if missing:
    raise FileNotFoundError(f"Missing files: {missing}")

print(f"✓ Project verified at {PROJECT_DIR}")
print(f"  Files: {len(os.listdir(PROJECT_DIR))} top-level entries")


# ══════════════════════════════════════════════════════════════════
# CELL 3 — GPU / VRAM check
# ══════════════════════════════════════════════════════════════════

import torch

assert torch.cuda.is_available(), "No GPU found! Set Runtime → T4 GPU."

gpu_name = torch.cuda.get_device_name(0)
vram_gb  = torch.cuda.get_device_properties(0).total_memory / 1e9

print(f"PyTorch  : {torch.__version__}")
print(f"CUDA     : {torch.version.cuda}")
print(f"Device   : {gpu_name}")
print(f"VRAM     : {vram_gb:.1f} GB")

if vram_gb < 12:
    print("⚠ Warning: < 12 GB VRAM — reduce batch size or use debug scale.")

DEVICE = torch.device("cuda")
DTYPE  = torch.bfloat16   # BF16 is natively supported on T4 (Ampere)
print(f"✓ Using {DEVICE} / {DTYPE}")


# ══════════════════════════════════════════════════════════════════
# CELL 4 — Configuration  ← EDIT THESE VALUES
# ══════════════════════════════════════════════════════════════════

from yeti_nepal_v1.config.model_config import get_full_config, get_debug_config
from yeti_nepal_v1.config.train_config import YetiTrainConfig

# ── Scale ─────────────────────────────────────────────────────────
# "debug"  → ~20M params, validates full pipeline in ~20 min
# "full"   → ~483M params, real multi-day training
SCALE = "debug"     # ← change to "full" when pipeline is validated

model_cfg = get_debug_config() if SCALE == "debug" else get_full_config()
train_cfg = YetiTrainConfig()

# ── Colab overrides ───────────────────────────────────────────────
if SCALE == "debug":
    train_cfg.phase1.max_train_tokens          = 50_000_000    # 50M tokens (~10 min)
    train_cfg.phase1.seq_len_max               = 512
    train_cfg.phase1.per_device_train_batch_size = 2
    train_cfg.phase1.gradient_accumulation_steps = 4
    train_cfg.phase1.save_steps                = 100
    train_cfg.phase1.logging_steps             = 10
    train_cfg.phase2.max_train_tokens          = 5_000_000     # 5M tokens
    train_cfg.phase2.per_device_train_batch_size = 2
    train_cfg.phase2.gradient_accumulation_steps = 4
    train_cfg.phase2.save_steps                = 50
    train_cfg.phase2.use_lora                  = False         # full params for debug
    train_cfg.phase3.max_train_samples         = 200
else:
    # Full training — checkpoint frequently so Colab disconnects don't lose work
    train_cfg.phase1.max_train_tokens          = 20_000_000_000  # 20B
    train_cfg.phase1.per_device_train_batch_size = 1
    train_cfg.phase1.gradient_accumulation_steps = 16
    train_cfg.phase1.save_steps                = 500
    train_cfg.phase2.max_train_tokens          = 5_000_000_000   # 5B
    train_cfg.phase3.max_train_samples         = 20_000

# Tokenizer (no auth required — Mistral tokenizer is public)
TOKENIZER_NAME = "mistralai/Mistral-7B-v0.1"

model_cfg.print_summary()
train_cfg.print_summary()


# ══════════════════════════════════════════════════════════════════
# CELL 5 — Tokenizer
# ══════════════════════════════════════════════════════════════════

from transformers import AutoTokenizer

print("Loading tokenizer …")
tokenizer = AutoTokenizer.from_pretrained(TOKENIZER_NAME, use_fast=True)

# Ensure pad token is set (Mistral uses eos as pad)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
if tokenizer.pad_token_id is None:
    tokenizer.pad_token_id = tokenizer.eos_token_id

# Sync vocab size with actual tokenizer
model_cfg.vocab_size = len(tokenizer)

print(f"✓ Tokenizer: {TOKENIZER_NAME}")
print(f"  Vocab size : {len(tokenizer)}")
print(f"  EOS token  : {tokenizer.eos_token!r} (id={tokenizer.eos_token_id})")
print(f"  PAD token  : {tokenizer.pad_token!r} (id={tokenizer.pad_token_id})")


# ══════════════════════════════════════════════════════════════════
# CELL 6 — Build model
# ══════════════════════════════════════════════════════════════════

from yeti_nepal_v1.model.yeti_core import YetiForCausalLM

print("Building model …")
model = YetiForCausalLM(model_cfg)
params = model.count_parameters()
print(f"✓ Model built — {params['total_M']} M parameters")

# ── Gradient checkpointing (correct API for custom architectures) ─
# Saves ~30-40% VRAM by recomputing activations during backward.
# Do NOT call .gradient_checkpointing_enable() — that's HF-specific.
if SCALE == "full":
    model.model.enable_gradient_checkpointing()   # our custom method

# ── Cast to BF16 and move to GPU ─────────────────────────────────
model = model.to(DTYPE).to(DEVICE)
print(f"✓ Model on {DEVICE} | dtype={DTYPE}")

# ── Memory summary ────────────────────────────────────────────────
allocated_gb = torch.cuda.memory_allocated() / 1e9
reserved_gb  = torch.cuda.memory_reserved()  / 1e9
print(f"  VRAM used  : {allocated_gb:.2f} GB allocated, {reserved_gb:.2f} GB reserved")


# ══════════════════════════════════════════════════════════════════
# CELL 7 — Data pipeline smoke-test
# ══════════════════════════════════════════════════════════════════

from yeti_nepal_v1.data.processor import YetiDataProcessor
from yeti_nepal_v1.data.loader import YetiDataLoader

print("Initialising data pipeline …")
processor  = YetiDataProcessor(TOKENIZER_NAME, seq_len=train_cfg.phase1.seq_len_max)
loader_fac = YetiDataLoader(processor)

# Pull a tiny slice to verify connectivity and column parsing
print("Smoke-testing pretrain stream (10K tokens) …")
test_loader  = loader_fac.get_pretrain_loader(train_cfg.phase1, max_tokens=10_000)
sample_batch = next(iter(test_loader))
print(f"✓ Pretrain batch shape : {sample_batch['input_ids'].shape}")

print("Smoke-testing SFT stream (1K tokens) …")
_sft_cfg = type('C', (), {
    'max_train_tokens': 1_000,
    'per_device_train_batch_size': 1,
    'dataloader_num_workers': 0,
})()

from yeti_nepal_v1.data.loader import SFTDataset
from torch.utils.data import DataLoader as _DL
_sft_ds  = SFTDataset(processor, max_tokens=1_000)
_sft_it  = iter(_DL(_sft_ds, batch_size=1, num_workers=0))
_sft_b   = next(_sft_it)
print(f"✓ SFT batch shapes     : input={_sft_b['input_ids'].shape}, "
      f"labels={_sft_b['labels'].shape}")

print("\n✓ Data pipeline OK — ready to train.")


# ══════════════════════════════════════════════════════════════════
# CELL 8 — PHASE 1: Pretraining  (FineWeb-Edu)
# ══════════════════════════════════════════════════════════════════
# Estimated time on T4:
#   debug (50M tokens)  ≈  15–30 min
#   full  (20B tokens)  ≈  many days (use Drive checkpointing)

os.makedirs(train_cfg.phase1.output_dir, exist_ok=True)

from yeti_nepal_v1.train.trainer import run_phase1

# To resume from a previous session, set the checkpoint path here:
RESUME_PHASE1 = None   # e.g. "/content/checkpoints/phase1/ckpt_step500.pt"

pretrain_loader = loader_fac.get_pretrain_loader(train_cfg.phase1)

model = run_phase1(
    model, pretrain_loader, train_cfg.phase1, DEVICE,
    resume_from=RESUME_PHASE1,
)
print("\n🎉 Phase 1 complete!")

# Free loader memory before SFT
del pretrain_loader
torch.cuda.empty_cache()


# ══════════════════════════════════════════════════════════════════
# CELL 9 — PHASE 2: Supervised Fine-Tuning  (OpenHermes + Open-Orca)
# ══════════════════════════════════════════════════════════════════

from yeti_nepal_v1.train.trainer import run_phase2

os.makedirs(train_cfg.phase2.output_dir, exist_ok=True)
sft_loader = loader_fac.get_sft_loader(train_cfg.phase2)

model = run_phase2(model, sft_loader, train_cfg.phase2, DEVICE)
print("\n🎉 Phase 2 complete!")

del sft_loader
torch.cuda.empty_cache()


# ══════════════════════════════════════════════════════════════════
# CELL 10 — PHASE 3: DPO Alignment  (UltraFeedback)
# ══════════════════════════════════════════════════════════════════

from yeti_nepal_v1.train.trainer import run_phase3
from yeti_nepal_v1.data.loader import DPODataset

os.makedirs(train_cfg.phase3.output_dir, exist_ok=True)

dpo_dataset = DPODataset(max_samples=train_cfg.phase3.max_train_samples)
model = run_phase3(model, tokenizer, dpo_dataset, train_cfg.phase3, DEVICE)
print("\n🎉 Phase 3 complete!")

torch.cuda.empty_cache()


# ══════════════════════════════════════════════════════════════════
# CELL 11 — Quick evaluation
# ══════════════════════════════════════════════════════════════════

import math

EVAL_TEXTS = [
    "The capital of Nepal is Kathmandu, a city rich in culture and history.",
    "Machine learning enables computers to learn patterns from large amounts of data.",
    "The quadratic formula x = (-b ± √(b²-4ac)) / 2a solves ax²+bx+c=0.",
]

def quick_perplexity(m, tok, texts, dev):
    m.eval()
    total_nll, total_tok = 0.0, 0
    with torch.no_grad():
        for t in texts:
            ids = tok.encode(t, return_tensors="pt",
                             max_length=256, truncation=True).to(dev)
            with torch.autocast(device_type="cuda", dtype=DTYPE):
                out = m(input_ids=ids, labels=ids)
            if out["loss"] is not None:
                total_nll += out["loss"].item() * ids.numel()
                total_tok += ids.numel()
    return math.exp(total_nll / max(total_tok, 1))

ppl = quick_perplexity(model, tokenizer, EVAL_TEXTS, DEVICE)
print(f"Perplexity      : {ppl:.2f}  (lower is better; untrained ~1000+)")

# Generation sample
model.eval()
prompt = "<|user|>\nWhat is 7 × 8?\n<|assistant|>\n<think>"
ids    = tokenizer.encode(prompt, return_tensors="pt").to(DEVICE)
with torch.no_grad():
    gen = model.generate_simple(
        ids, max_new_tokens=80, temperature=0.7,
        eos_token_id=tokenizer.eos_token_id,
    )
print("\nSample generation:")
print("─" * 50)
print(tokenizer.decode(gen[0], skip_special_tokens=True))
print("─" * 50)


# ══════════════════════════════════════════════════════════════════
# CELL 12 — Save final model + (optional) export to GGUF
# ══════════════════════════════════════════════════════════════════

FINAL_DIR = "/content/yeti_final_model"
os.makedirs(FINAL_DIR, exist_ok=True)

# ── Save PyTorch checkpoint ───────────────────────────────────────
CKPT_PATH = os.path.join(FINAL_DIR, "yeti_final.pt")
torch.save({
    "step":   "final",
    "model":  model.state_dict(),
    "config": model_cfg,
}, CKPT_PATH)
size_mb = os.path.getsize(CKPT_PATH) / 1e6
print(f"✓ Checkpoint saved → {CKPT_PATH}  ({size_mb:.0f} MB)")

# ── Save safetensors (optional, better for sharing) ──────────────
try:
    from safetensors.torch import save_file
    st_path = os.path.join(FINAL_DIR, "model.safetensors")
    save_file({k: v.contiguous() for k, v in model.state_dict().items()}, st_path)
    print(f"✓ safetensors  → {st_path}")
except ImportError:
    print("ℹ safetensors not installed, skipping.")

# ── Copy to Google Drive (set True to enable) ─────────────────────
SAVE_TO_DRIVE = False
if SAVE_TO_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive", force_remount=False)
    import shutil
    dst = "/content/drive/MyDrive/yeti_final_model"
    shutil.copytree(FINAL_DIR, dst, dirs_exist_ok=True)
    print(f"✓ Copied to Drive → {dst}")

# ── GGUF export (set True to run llama.cpp conversion) ───────────
EXPORT_GGUF = False
if EXPORT_GGUF:
    result = subprocess.run([
        sys.executable, "/content/yeti_nepal_v1/export_gguf.py",
        "--checkpoint", CKPT_PATH,
        "--output_dir", "/content/yeti_gguf",
        "--tokenizer",  TOKENIZER_NAME,
        "--quant",      "Q4_K_M",
    ], capture_output=False)
    if result.returncode == 0:
        print("✓ GGUF export complete → /content/yeti_gguf/")
    else:
        print("✗ GGUF export failed — check output above.")

print("\n🏔️  Yeti Nepal v1 pipeline complete!")
print(f"   Scale   : {SCALE}")
print(f"   Params  : {model.count_parameters()['total_M']} M")
print(f"   VRAM    : {torch.cuda.memory_allocated()/1e9:.2f} GB used")
