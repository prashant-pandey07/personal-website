"""
Export Yeti Nepal v1 → GGUF (4-bit) for llama.cpp / vLLM
==========================================================
Converts the trained PyTorch checkpoint to a GGUF file that can be
served with llama.cpp on any CPU/GPU without Python.

Usage:
    python export_gguf.py \
        --checkpoint ./checkpoints/phase2_final_step1000.pt \
        --output_dir ./gguf_export \
        --quant Q4_K_M
"""

import os
import argparse
import subprocess
import torch

import sys
sys.path.insert(0, os.path.dirname(__file__))

from config.model_config import get_full_config
from model.yeti_core import YetiForCausalLM


# ─────────────────────────────────────────────────────────────────────
# Step 1: Save as HuggingFace-compatible safetensors
# ─────────────────────────────────────────────────────────────────────

def save_as_hf_model(model, tokenizer_name: str, output_dir: str):
    """
    Saves the model in a HuggingFace-like directory layout so
    llama.cpp's convert_hf_to_gguf.py can read it.
    """
    os.makedirs(output_dir, exist_ok=True)

    try:
        from safetensors.torch import save_file
        tensors = {k: v.contiguous() for k, v in model.state_dict().items()}
        save_file(tensors, os.path.join(output_dir, "model.safetensors"))
        print(f"  [Export] Saved safetensors → {output_dir}/model.safetensors")
    except ImportError:
        # Fallback: plain .pt
        torch.save(model.state_dict(), os.path.join(output_dir, "model.pt"))
        print(f"  [Export] safetensors not available — saved model.pt")

    # Minimal config.json so llama.cpp recognises the layout
    import json
    cfg = model.config
    hf_config = {
        "model_type":             "llama",  # closest HF type for gguf conversion
        "hidden_size":            cfg.hidden_size,
        "intermediate_size":      cfg.ffn_hidden_size,
        "num_hidden_layers":      cfg.num_layers,
        "num_attention_heads":    cfg.num_attention_heads,
        "num_key_value_heads":    cfg.num_kv_heads,
        "max_position_embeddings": cfg.max_position_embeddings,
        "vocab_size":             cfg.vocab_size,
        "rms_norm_eps":           cfg.rms_norm_eps,
        "rope_theta":             cfg.rope_theta,
        "bos_token_id":           cfg.bos_token_id,
        "eos_token_id":           cfg.eos_token_id,
        "torch_dtype":            "bfloat16",
    }
    with open(os.path.join(output_dir, "config.json"), "w") as f:
        json.dump(hf_config, f, indent=2)
    print(f"  [Export] Saved config.json")

    # Copy tokenizer files from the reference tokenizer
    try:
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained(tokenizer_name)
        tok.save_pretrained(output_dir)
        print(f"  [Export] Saved tokenizer files")
    except Exception as e:
        print(f"  [Export] Tokenizer save skipped: {e}")


# ─────────────────────────────────────────────────────────────────────
# Step 2: Clone llama.cpp and convert
# ─────────────────────────────────────────────────────────────────────

def convert_to_gguf(hf_dir: str, gguf_dir: str, quant: str = "Q4_K_M"):
    """
    Clones llama.cpp (if not present) and runs convert + quantize.
    Requires: git, cmake, make (available on Colab Linux).
    """
    os.makedirs(gguf_dir, exist_ok=True)
    llamacpp_dir = "./llama.cpp"

    # Clone
    if not os.path.isdir(llamacpp_dir):
        print("  [GGUF] Cloning llama.cpp …")
        subprocess.run(["git", "clone", "--depth=1",
                        "https://github.com/ggerganov/llama.cpp",
                        llamacpp_dir], check=True)

    # Install python requirements for the converter
    req = os.path.join(llamacpp_dir, "requirements.txt")
    if os.path.exists(req):
        subprocess.run(["pip", "install", "-q", "-r", req], check=True)

    # Convert HF → F16 GGUF
    f16_path = os.path.join(gguf_dir, "yeti-f16.gguf")
    converter = os.path.join(llamacpp_dir, "convert_hf_to_gguf.py")
    if not os.path.exists(converter):
        converter = os.path.join(llamacpp_dir, "convert.py")  # older versions

    print(f"  [GGUF] Converting to F16 GGUF …")
    subprocess.run([
        "python", converter,
        hf_dir,
        "--outfile", f16_path,
        "--outtype", "f16",
    ], check=True)
    print(f"  [GGUF] F16 GGUF → {f16_path}")

    # Build llama-quantize binary
    q_binary = os.path.join(llamacpp_dir, "llama-quantize")
    if not os.path.exists(q_binary):
        q_binary = os.path.join(llamacpp_dir, "quantize")   # older name
    if not os.path.exists(q_binary):
        print("  [GGUF] Building llama-quantize …")
        subprocess.run(["cmake", "-B", "build"], cwd=llamacpp_dir, check=True)
        subprocess.run(["cmake", "--build", "build", "--config", "Release",
                        "-j4"], cwd=llamacpp_dir, check=True)
        q_binary = os.path.join(llamacpp_dir, "build", "bin", "llama-quantize")

    # Quantize F16 → Q4_K_M
    q_path = os.path.join(gguf_dir, f"yeti-{quant}.gguf")
    print(f"  [GGUF] Quantizing to {quant} …")
    subprocess.run([q_binary, f16_path, q_path, quant], check=True)
    print(f"  [GGUF] ✓ Final GGUF → {q_path}")
    return q_path


# ─────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint",     type=str, required=True,
                        help="Path to .pt checkpoint file")
    parser.add_argument("--output_dir",     type=str, default="./gguf_export")
    parser.add_argument("--hf_dir",         type=str, default="./hf_export",
                        help="Intermediate HF-format directory")
    parser.add_argument("--tokenizer",      type=str,
                        default="mistralai/Mistral-7B-v0.1")
    parser.add_argument("--quant",          type=str, default="Q4_K_M",
                        choices=["Q4_K_M", "Q5_K_M", "Q8_0", "Q2_K"])
    parser.add_argument("--skip_convert",   action="store_true",
                        help="Skip llama.cpp conversion (just export HF format)")
    args = parser.parse_args()

    print("=" * 55)
    print("  Yeti Nepal v1 — GGUF Export")
    print("=" * 55)

    # Load model
    print(f"\n[1/3] Loading checkpoint: {args.checkpoint}")
    config = get_full_config()
    model  = YetiForCausalLM(config)
    state  = torch.load(args.checkpoint, map_location="cpu")
    model.load_state_dict(state.get("model", state), strict=False)
    model.eval()
    params = model.count_parameters()
    print(f"  Model: {params['total_M']} M parameters")

    # Export as HF format
    print(f"\n[2/3] Saving HF-format model → {args.hf_dir}")
    save_as_hf_model(model, args.tokenizer, args.hf_dir)

    # Convert + quantize
    if not args.skip_convert:
        print(f"\n[3/3] Converting to {args.quant} GGUF → {args.output_dir}")
        gguf_path = convert_to_gguf(args.hf_dir, args.output_dir, args.quant)
        size_mb = os.path.getsize(gguf_path) / 1e6
        print(f"\n✓ Export complete!")
        print(f"  GGUF file : {gguf_path}")
        print(f"  File size : {size_mb:.0f} MB")
        print(f"\nRun with llama.cpp:")
        print(f"  ./llama-cli -m {gguf_path} -n 256 -p 'Hello, I am Yeti Nepal.'")
    else:
        print(f"\n✓ HF export complete (GGUF conversion skipped).")
        print(f"  Directory: {args.hf_dir}")


if __name__ == "__main__":
    main()
