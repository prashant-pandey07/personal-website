"""
Yeti Nepal v1-500M — Model Configuration
=========================================
Defines every architectural hyperparameter for the hybrid
Mamba-2 SSM + GQA Attention + 2-Expert MoE model.

Target: ~465–510M parameters on Google Colab T4 (16 GB VRAM).
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class YetiModelConfig:
    # ── Vocabulary ─────────────────────────────────────────────────
    vocab_size: int = 32_000        # LLaMA-compatible BPE vocab
    pad_token_id: int = 0
    eos_token_id: int = 2
    bos_token_id: int = 1

    # ── Core Dimensions ────────────────────────────────────────────
    hidden_size: int = 1024         # d_model
    num_layers: int = 24            # total layers (SSM + GQA)
    attention_every_n: int = 4      # every Nth layer → GQA; rest → Mamba-2

    # ── GQA Attention ──────────────────────────────────────────────
    num_attention_heads: int = 8    # total query heads
    num_kv_heads: int = 2           # key/value heads  (4 queries per KV pair)
    max_position_embeddings: int = 4096
    rope_theta: float = 10_000.0   # RoPE base frequency
    attention_dropout: float = 0.0

    # ── Mamba-2 SSM ────────────────────────────────────────────────
    ssm_expand: int = 2             # d_inner = hidden_size * ssm_expand
    ssm_state_dim: int = 64         # SSM state N (d_state)
    ssm_conv_width: int = 4         # depthwise conv kernel size
    ssm_dt_rank: str = "auto"       # "auto" → hidden_size // 16
    ssm_dt_min: float = 0.001
    ssm_dt_max: float = 0.1
    ssm_dt_scale: float = 1.0
    ssm_dt_init_floor: float = 1e-4

    # ── Mixture of Experts ─────────────────────────────────────────
    num_experts: int = 2            # 2 experts per layer
    num_experts_per_tok: int = 1    # Top-1 routing at inference
    ffn_hidden_size: int = 2048     # expert FFN width (2× hidden_size)
    moe_capacity_factor: float = 1.25
    balance_loss_coeff: float = 0.01   # α in Switch load-balance loss
    z_loss_coeff: float = 0.001        # ST-MoE router z-loss coefficient

    # ── Normalization ──────────────────────────────────────────────
    rms_norm_eps: float = 1e-6

    # ── Dropout ────────────────────────────────────────────────────
    dropout: float = 0.0            # 0.0 is best practice at 500M scale

    # ── Embedding ──────────────────────────────────────────────────
    tie_word_embeddings: bool = False

    # ── Chain-of-Thought special tokens ────────────────────────────
    think_start_token: str = "<think>"
    think_end_token: str = "</think>"
    answer_start_token: str = "<answer>"
    answer_end_token: str = "</answer>"

    # ── Model ID ───────────────────────────────────────────────────
    model_type: str = "yeti_nepal_v1"
    model_name: str = "Yeti-Nepal-v1-500M"

    # ───────────────────────────────────────────────────────────────
    # Derived properties
    # ───────────────────────────────────────────────────────────────

    @property
    def dt_rank(self) -> int:
        """Rank of the delta (Δ) projection in SSM."""
        if self.ssm_dt_rank == "auto":
            return max(1, self.hidden_size // 16)
        return int(self.ssm_dt_rank)

    @property
    def ssm_d_inner(self) -> int:
        return self.hidden_size * self.ssm_expand

    @property
    def head_dim(self) -> int:
        return self.hidden_size // self.num_attention_heads

    @property
    def num_attention_layers(self) -> int:
        """Number of layers using GQA attention (every attention_every_n-th)."""
        return self.num_layers // self.attention_every_n

    @property
    def num_ssm_layers(self) -> int:
        """Number of layers using Mamba-2 SSM."""
        return self.num_layers - self.num_attention_layers

    # ───────────────────────────────────────────────────────────────
    # Parameter estimation
    # ───────────────────────────────────────────────────────────────

    def estimate_params(self) -> dict:
        """
        Rough parameter count estimation per component.
        Returns dict with per-section counts in millions.
        """
        H = self.hidden_size
        V = self.vocab_size

        # Embedding table
        emb = V * H

        # ── SSM block per layer ──
        d_inner = self.ssm_d_inner
        in_proj  = H * (d_inner * 2)          # z + x projections
        conv     = self.ssm_conv_width * d_inner
        x_proj   = d_inner * (self.dt_rank + self.ssm_state_dim * 2)  # dt, B, C
        dt_proj  = self.dt_rank * d_inner
        out_proj = d_inner * H
        ssm_per  = in_proj + conv + x_proj + dt_proj + out_proj + d_inner  # +D
        ssm_total = self.num_ssm_layers * ssm_per

        # ── GQA attention block per layer ──
        kv_dim   = self.num_kv_heads * self.head_dim
        q_proj   = H * H
        k_proj   = H * kv_dim
        v_proj   = H * kv_dim
        o_proj   = H * H
        attn_per = q_proj + k_proj + v_proj + o_proj
        attn_total = self.num_attention_layers * attn_per

        # ── MoE (2-expert SwiGLU) per layer ──
        # SwiGLU: gate + up + down  →  3 matrices per expert
        expert_params = 3 * H * self.ffn_hidden_size
        router_params = H * self.num_experts
        moe_per = self.num_experts * expert_params + router_params
        moe_total = self.num_layers * moe_per

        # Layer norms (RMSNorm) — one per sub-block × 2 per layer
        norm_total = self.num_layers * 2 * H

        total = emb + ssm_total + attn_total + moe_total + norm_total

        return {
            "embedding_M":   round(emb / 1e6, 1),
            "ssm_total_M":   round(ssm_total / 1e6, 1),
            "attn_total_M":  round(attn_total / 1e6, 1),
            "moe_total_M":   round(moe_total / 1e6, 1),
            "norms_M":       round(norm_total / 1e6, 1),
            "TOTAL_M":       round(total / 1e6, 1),
        }

    def __post_init__(self):
        assert self.num_attention_heads % self.num_kv_heads == 0, (
            "num_attention_heads must be divisible by num_kv_heads"
        )
        assert self.num_layers % self.attention_every_n == 0, (
            "num_layers must be divisible by attention_every_n"
        )
        params = self.estimate_params()
        total  = params["TOTAL_M"]
        if not (400 <= total <= 600):
            import warnings
            warnings.warn(
                f"Parameter count {total}M is outside the target 400–600M range. "
                f"Breakdown: {params}",
                stacklevel=2,
            )

    def print_summary(self):
        params = self.estimate_params()
        print("=" * 55)
        print(f"  {self.model_name} — Architecture Summary")
        print("=" * 55)
        print(f"  Layers total   : {self.num_layers}")
        print(f"    ├─ SSM       : {self.num_ssm_layers}  (Mamba-2)")
        print(f"    └─ GQA Attn : {self.num_attention_layers}  (every {self.attention_every_n}th layer)")
        print(f"  Hidden size    : {self.hidden_size}")
        print(f"  SSM d_inner    : {self.ssm_d_inner}")
        print(f"  SSM state dim  : {self.ssm_state_dim}")
        print(f"  Attn heads Q   : {self.num_attention_heads}")
        print(f"  Attn heads KV  : {self.num_kv_heads}  (GQA ratio {self.num_attention_heads//self.num_kv_heads}:1)")
        print(f"  Experts/layer  : {self.num_experts}  (Top-{self.num_experts_per_tok} routing)")
        print(f"  FFN hidden     : {self.ffn_hidden_size}")
        print(f"  Vocab size     : {self.vocab_size}")
        print(f"  Max seq len    : {self.max_position_embeddings}")
        print("-" * 55)
        for k, v in params.items():
            print(f"  {k:<18}: {v} M")
        print("=" * 55)


# ── Preset configs ─────────────────────────────────────────────────

def get_debug_config() -> YetiModelConfig:
    """Tiny config for fast iteration / unit tests (≈ 50M params)."""
    return YetiModelConfig(
        hidden_size=256,
        num_layers=8,
        ffn_hidden_size=512,
        ssm_state_dim=16,
        ssm_expand=2,
        attention_every_n=4,
        max_position_embeddings=512,
    )


def get_small_config() -> YetiModelConfig:
    """~120M param config for Phase-1 scale experiments."""
    return YetiModelConfig(
        hidden_size=512,
        num_layers=16,
        ffn_hidden_size=1024,
        ssm_state_dim=32,
        ssm_expand=2,
        attention_every_n=4,
        max_position_embeddings=2048,
    )


def get_medium_config() -> YetiModelConfig:
    """~300M param config (Phase-2 scale)."""
    return YetiModelConfig(
        hidden_size=768,
        num_layers=20,
        ffn_hidden_size=1536,
        ssm_state_dim=48,
        ssm_expand=2,
        attention_every_n=4,
        max_position_embeddings=4096,
    )


def get_full_config() -> YetiModelConfig:
    """~480M param config — final Yeti Nepal v1-500M."""
    return YetiModelConfig(
        hidden_size=1024,
        num_layers=24,
        ffn_hidden_size=2048,
        ssm_state_dim=64,
        ssm_expand=2,
        attention_every_n=4,
        num_attention_heads=8,
        num_kv_heads=2,
        max_position_embeddings=4096,
    )
