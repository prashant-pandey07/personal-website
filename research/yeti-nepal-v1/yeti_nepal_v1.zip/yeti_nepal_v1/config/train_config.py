"""
Yeti Nepal v1-500M — Training Configuration
=============================================
Hyperparameters for all three training phases:
  Phase 1 — Pretraining  (FineWeb-Edu)
  Phase 2 — SFT          (OpenHermes + Open-Orca CoT + Cosmopedia)
  Phase 3 — DPO          (preference alignment)

Designed for Google Colab T4 (16 GB VRAM) + Unsloth.
"""

from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class Phase1Config:
    """Autoregressive pretraining on FineWeb-Edu."""

    # ── Data ──────────────────────────────────────────────────────
    dataset_name: str = "HuggingFaceFW/fineweb-edu"
    dataset_config: str = "sample-10BT"          # 10B-token subset
    max_train_tokens: int = 20_000_000_000       # 20B tokens (Chinchilla-optimal for 500M)
    streaming: bool = True                        # stream from HuggingFace Hub

    # ── Sequence ──────────────────────────────────────────────────
    seq_len_start: int = 512                     # warm-up context length
    seq_len_max: int = 2048                      # ramp to this by mid-training
    seq_len_final: int = 4096                    # extended context in last 20%

    # ── Batch ─────────────────────────────────────────────────────
    per_device_train_batch_size: int = 1         # T4 micro-batch
    gradient_accumulation_steps: int = 16        # effective batch ~16K tokens at 1K seq
    dataloader_num_workers: int = 2

    # ── Optimiser ─────────────────────────────────────────────────
    optim: str = "adamw_torch_fused"
    learning_rate: float = 1e-4
    lr_scheduler_type: str = "cosine"
    warmup_ratio: float = 0.01                   # 1% of steps for warmup
    weight_decay: float = 0.1
    adam_beta1: float = 0.9
    adam_beta2: float = 0.98
    adam_epsilon: float = 1e-8
    max_grad_norm: float = 1.0

    # ── Precision & Memory ────────────────────────────────────────
    bf16: bool = True
    fp16: bool = False
    gradient_checkpointing: bool = True
    dataloader_pin_memory: bool = True

    # ── Logging & Checkpoints ─────────────────────────────────────
    logging_steps: int = 50
    save_steps: int = 500
    save_total_limit: int = 3
    output_dir: str = "./checkpoints/phase1"
    run_name: str = "yeti-pretrain"
    report_to: str = "none"                      # set "wandb" if available

    # ── Evaluation ────────────────────────────────────────────────
    eval_steps: int = 500
    eval_dataset_size: int = 2000                # tokens for held-out perplexity


@dataclass
class Phase2Config:
    """Supervised fine-tuning on instruction + chain-of-thought data."""

    # ── Data ──────────────────────────────────────────────────────
    datasets: List[str] = field(default_factory=lambda: [
        "teknium/OpenHermes-2.5",               # 242K high-quality instruct (ShareGPT)
        "Open-Orca/OpenOrca",                   # Orca-style CoT reasoning (system_prompt, question, response)
        "HuggingFaceTB/cosmopedia",             # synthetic educational text (text col)
    ])
    max_train_tokens: int = 5_000_000_000       # 5B tokens SFT
    cot_weight: float = 2.0                     # up-weight CoT examples in loss

    # ── Sequence ──────────────────────────────────────────────────
    seq_len: int = 2048
    packing: bool = True                         # pack short examples together

    # ── LoRA (optional, saves VRAM) ───────────────────────────────
    use_lora: bool = True
    lora_r: int = 64
    lora_alpha: int = 128
    lora_dropout: float = 0.05
    lora_target_modules: List[str] = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
        "in_proj", "out_proj",
    ])

    # ── Batch ─────────────────────────────────────────────────────
    per_device_train_batch_size: int = 2
    gradient_accumulation_steps: int = 8
    dataloader_num_workers: int = 2

    # ── Optimiser ─────────────────────────────────────────────────
    optim: str = "adamw_torch_fused"
    learning_rate: float = 5e-5
    lr_scheduler_type: str = "cosine"
    warmup_ratio: float = 0.03
    weight_decay: float = 0.01
    adam_beta1: float = 0.9
    adam_beta2: float = 0.95
    max_grad_norm: float = 1.0
    num_train_epochs: int = 2

    # ── Precision & Memory ────────────────────────────────────────
    bf16: bool = True
    gradient_checkpointing: bool = True

    # ── Chat Template ─────────────────────────────────────────────
    # System prompt injected before every conversation
    system_prompt: str = (
        "You are Yeti Nepal, a helpful and thoughtful AI assistant. "
        "When solving complex problems, think step by step inside <think> tags, "
        "then give your final answer inside <answer> tags."
    )

    # ── Logging & Checkpoints ─────────────────────────────────────
    logging_steps: int = 25
    save_steps: int = 250
    save_total_limit: int = 3
    output_dir: str = "./checkpoints/phase2"
    run_name: str = "yeti-sft"
    report_to: str = "none"


@dataclass
class Phase3Config:
    """Direct Preference Optimisation (DPO) for alignment."""

    # ── Data ──────────────────────────────────────────────────────
    # Expects a dataset with {"prompt", "chosen", "rejected"} columns
    dataset_name: str = "HuggingFaceH4/ultrafeedback_binarized"
    max_train_samples: int = 20_000

    # ── DPO Parameters ────────────────────────────────────────────
    beta: float = 0.1                            # KL-divergence temperature
    loss_type: str = "sigmoid"                   # "sigmoid" | "hinge" | "ipo"
    label_smoothing: float = 0.0

    # ── Sequence ──────────────────────────────────────────────────
    max_prompt_length: int = 512
    max_length: int = 1024

    # ── LoRA (reuse from Phase 2 or fine-tune fresh) ──────────────
    use_lora: bool = True
    lora_r: int = 32
    lora_alpha: int = 64
    lora_dropout: float = 0.05

    # ── Batch ─────────────────────────────────────────────────────
    per_device_train_batch_size: int = 1
    gradient_accumulation_steps: int = 8

    # ── Optimiser ─────────────────────────────────────────────────
    learning_rate: float = 5e-7
    lr_scheduler_type: str = "cosine"
    warmup_ratio: float = 0.1
    weight_decay: float = 0.0
    max_grad_norm: float = 1.0
    num_train_epochs: int = 1

    # ── Precision ─────────────────────────────────────────────────
    bf16: bool = True
    gradient_checkpointing: bool = True

    # ── Logging & Checkpoints ─────────────────────────────────────
    logging_steps: int = 10
    save_steps: int = 100
    save_total_limit: int = 2
    output_dir: str = "./checkpoints/phase3"
    run_name: str = "yeti-dpo"
    report_to: str = "none"


@dataclass
class YetiTrainConfig:
    """
    Top-level training config — contains all three phases plus
    global settings shared across phases.
    """
    phase1: Phase1Config = field(default_factory=Phase1Config)
    phase2: Phase2Config = field(default_factory=Phase2Config)
    phase3: Phase3Config = field(default_factory=Phase3Config)

    # ── Global ────────────────────────────────────────────────────
    seed: int = 42
    tokenizer_name: str = "mistralai/Mistral-7B-v0.1"  # 32K BPE vocab, no auth required
    tokenizer_fallback: str = "NousResearch/Llama-2-7b-hf"  # fallback (also no auth)

    # ── Unsloth ───────────────────────────────────────────────────
    use_unsloth: bool = True                     # enable Unsloth kernels
    unsloth_max_seq_length: int = 4096
    load_in_4bit: bool = True                    # 4-bit quantised training

    # ── Paths ─────────────────────────────────────────────────────
    base_checkpoint_dir: str = "./checkpoints"
    final_model_dir: str = "./final_model"
    gguf_output_dir: str = "./gguf_export"

    # ── Progressive scaling roadmap ───────────────────────────────
    # Set this to the config size you want to train in this run.
    # Options: "debug" | "small" | "medium" | "full"
    scale: str = "full"

    def print_summary(self):
        print("=" * 55)
        print("  Yeti Nepal v1 — Training Config Summary")
        print("=" * 55)
        print(f"  Scale target   : {self.scale}")
        print(f"  Seed           : {self.seed}")
        print(f"  Unsloth        : {self.use_unsloth}")
        print(f"  4-bit quant    : {self.load_in_4bit}")
        print(f"  Tokenizer      : {self.tokenizer_name}")
        print()
        print(f"  Phase 1 — Pretrain")
        print(f"    Dataset      : {self.phase1.dataset_name}")
        print(f"    Target tokens: {self.phase1.max_train_tokens / 1e9:.0f}B")
        print(f"    Seq len      : {self.phase1.seq_len_start}→{self.phase1.seq_len_max}→{self.phase1.seq_len_final}")
        print(f"    LR           : {self.phase1.learning_rate}")
        print()
        print(f"  Phase 2 — SFT")
        print(f"    Datasets     : {len(self.phase2.datasets)} sources")
        print(f"    Target tokens: {self.phase2.max_train_tokens / 1e9:.0f}B")
        print(f"    LoRA         : r={self.phase2.lora_r}, α={self.phase2.lora_alpha}")
        print(f"    LR           : {self.phase2.learning_rate}")
        print()
        print(f"  Phase 3 — DPO")
        print(f"    Dataset      : {self.phase3.dataset_name}")
        print(f"    Samples      : {self.phase3.max_train_samples:,}")
        print(f"    Beta         : {self.phase3.beta}")
        print(f"    LR           : {self.phase3.learning_rate}")
        print("=" * 55)
