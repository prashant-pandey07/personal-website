"""
Data Loader — Streaming from HuggingFace Hub
=============================================
Verified dataset repos & column schemas (May 2026):

  FineWeb-Edu        HuggingFaceFW/fineweb-edu     name="sample-10BT"   col: text
  OpenHermes-2.5     teknium/OpenHermes-2.5        split="train"        col: conversations [{from, value}]
  Open-Orca          Open-Orca/OpenOrca            split="train"        col: system_prompt, question, response
  Cosmopedia         HuggingFaceTB/cosmopedia      split="train"        col: text, topic, title
  UltraFeedback      HuggingFaceH4/ultrafeedback_binarized  split="train_prefs"
                     col: prompt (str), chosen/rejected (list of {role, content} dicts)

All datasets support streaming=True (Parquet-backed).
"""

import torch
from torch.utils.data import IterableDataset, DataLoader
from datasets import load_dataset, interleave_datasets
from typing import Optional, Iterator, List, Dict
from .processor import YetiDataProcessor, format_chat, SYSTEM_PROMPT


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _extract_conversation_text(example: Dict) -> Optional[str]:
    """
    Normalise any SFT example into a single formatted training string.
    Handles all known column schemas:
      1. ShareGPT: conversations=[{from, value}, ...]
      2. Orca:     system_prompt, question, response
      3. Raw text: text (Cosmopedia-style)
    Returns None if the example can't be parsed.
    """
    # ── Schema 1: ShareGPT (OpenHermes-2.5) ────────────────────────
    convs = example.get("conversations")
    if convs and isinstance(convs, list) and len(convs) >= 2:
        system = ""
        user   = ""
        asst   = ""
        for turn in convs:
            role = turn.get("from", "")
            text = turn.get("value", "")
            if role == "system":
                system = text
            elif role == "human":
                user = text
            elif role == "gpt":
                asst = text
        if user and asst:
            return format_chat(system or SYSTEM_PROMPT, user, asst)

    # ── Schema 2: Orca-style (system_prompt, question, response) ───
    question = example.get("question", "")
    response = example.get("response", "")
    if question and response:
        sys_p = example.get("system_prompt", SYSTEM_PROMPT)
        return format_chat(sys_p, question, response)

    # ── Schema 3: Raw text (Cosmopedia) ────────────────────────────
    text = example.get("text", "")
    if text and len(text) > 100:
        return text  # already clean educational prose — use as-is

    return None


def _extract_dpo_text(messages: object) -> str:
    """
    Extract the assistant reply from UltraFeedback chosen/rejected.
    The field is a list of {role, content} dicts — we want the last
    assistant message.
    """
    if isinstance(messages, list):
        for msg in reversed(messages):
            if isinstance(msg, dict) and msg.get("role") == "assistant":
                return msg.get("content", "")
        # Fallback: grab last message's content regardless of role
        if messages and isinstance(messages[-1], dict):
            return messages[-1].get("content", "")
    if isinstance(messages, str):
        return messages
    return ""


# ─────────────────────────────────────────────────────────────────────
# Phase 1 — Pretraining dataset
# ─────────────────────────────────────────────────────────────────────

class PretrainDataset(IterableDataset):
    """
    Streams FineWeb-Edu tokens.
    Each item: {"input_ids": [seq_len], "labels": [seq_len]}
    """

    def __init__(self, processor: YetiDataProcessor, dataset_name: str,
                 config_name: str = "sample-10BT", split: str = "train",
                 max_tokens: Optional[int] = None):
        self.processor   = processor
        self.max_tokens  = max_tokens
        self._seen       = 0

        # FineWeb-Edu uses `name=` for config selection, NOT `config_name=`
        print(f"[PretrainDataset] Loading {dataset_name} (config={config_name}) streaming …")
        self.dataset = load_dataset(
            dataset_name,
            name=config_name,
            split=split,
            streaming=True,
        )

    def __iter__(self) -> Iterator:
        self._seen = 0
        for example in self.dataset:
            if self.max_tokens and self._seen >= self.max_tokens:
                return
            text = example.get("text", "")
            if not text:
                continue
            batch = self.processor.tokenize_pretrain({"text": [text]})
            for ids in batch["input_ids"]:
                self._seen += len(ids)
                yield {
                    "input_ids": torch.tensor(ids, dtype=torch.long),
                    "labels":    torch.tensor(ids, dtype=torch.long),
                }


# ─────────────────────────────────────────────────────────────────────
# Phase 2 — SFT dataset
# ─────────────────────────────────────────────────────────────────────

# Verified repos, splits, and sampling weights
_SFT_SOURCES = [
    # (repo_id,                       split,    weight,  description)
    ("teknium/OpenHermes-2.5",        "train",  1.0,     "ShareGPT instruct"),
    ("Open-Orca/OpenOrca",            "train",  1.5,     "Orca-style CoT reasoning"),
    ("HuggingFaceTB/cosmopedia",      "train",  0.5,     "Synthetic educational text"),
]


class SFTDataset(IterableDataset):
    """
    Interleaves verified SFT sources with probabilistic sampling.
    Handles all three column schemas via _extract_conversation_text().
    Each item: {"input_ids", "attention_mask", "labels"}
    """

    def __init__(self, processor: YetiDataProcessor,
                 max_tokens: Optional[int] = None):
        self.processor  = processor
        self.max_tokens = max_tokens
        self._seen      = 0
        self._build_dataset()

    def _build_dataset(self):
        datasets_list, probs = [], []
        for repo, split, weight, desc in _SFT_SOURCES:
            try:
                print(f"[SFTDataset] Loading {repo} ({desc}) …")
                ds = load_dataset(repo, split=split, streaming=True)
                datasets_list.append(ds)
                probs.append(weight)
                print(f"  ✓ {repo} loaded")
            except Exception as e:
                print(f"  ✗ {repo} failed: {e}")

        if not datasets_list:
            raise RuntimeError(
                "No SFT datasets loaded. Check internet & HuggingFace access."
            )

        total = sum(probs)
        probs = [p / total for p in probs]
        print(f"[SFTDataset] Interleaving {len(datasets_list)} sources, "
              f"probabilities: {[round(p,2) for p in probs]}")
        self._dataset = interleave_datasets(
            datasets_list, probabilities=probs, seed=42, stopping_strategy="all_exhausted"
        )

    def __iter__(self) -> Iterator:
        self._seen = 0
        for example in self._dataset:
            if self.max_tokens and self._seen >= self.max_tokens:
                return

            # Normalise any schema → single training string
            text = _extract_conversation_text(example)
            if text is None:
                continue

            batch = self.processor.tokenize_sft_text(text)
            if not batch["input_ids"]:
                continue

            ids  = batch["input_ids"]
            mask = batch["attention_mask"]
            lbls = batch["labels"]
            self._seen += sum(mask)
            yield {
                "input_ids":      torch.tensor(ids,  dtype=torch.long),
                "attention_mask": torch.tensor(mask, dtype=torch.long),
                "labels":         torch.tensor(lbls, dtype=torch.long),
            }


# ─────────────────────────────────────────────────────────────────────
# Phase 3 — DPO dataset
# ─────────────────────────────────────────────────────────────────────

class DPODataset(IterableDataset):
    """
    Streams UltraFeedback binarised preference pairs for DPO.

    Columns: prompt (str), chosen (list[{role,content}]),
             rejected (list[{role,content}])
    Split:   train_prefs

    Each item: {"prompt": str, "chosen": str, "rejected": str}
    """

    def __init__(self,
                 dataset_name: str = "HuggingFaceH4/ultrafeedback_binarized",
                 split: str = "train_prefs",
                 max_samples: Optional[int] = None):
        self.max_samples = max_samples
        self._count      = 0
        print(f"[DPODataset] Loading {dataset_name} split={split} streaming …")
        self._dataset = load_dataset(dataset_name, split=split, streaming=True)

    def __iter__(self) -> Iterator:
        self._count = 0
        for example in self._dataset:
            if self.max_samples and self._count >= self.max_samples:
                return

            prompt   = example.get("prompt", "")
            chosen   = _extract_dpo_text(example.get("chosen", []))
            rejected = _extract_dpo_text(example.get("rejected", []))

            if prompt and chosen and rejected:
                self._count += 1
                yield {
                    "prompt":   prompt,
                    "chosen":   chosen,
                    "rejected": rejected,
                }


# ─────────────────────────────────────────────────────────────────────
# DataLoader factory
# ─────────────────────────────────────────────────────────────────────

class YetiDataLoader:
    """Factory: returns ready-to-use DataLoader for each training phase."""

    def __init__(self, processor: YetiDataProcessor):
        self.processor = processor

    def get_pretrain_loader(self, cfg, max_tokens: Optional[int] = None) -> DataLoader:
        ds = PretrainDataset(
            self.processor,
            dataset_name=cfg.dataset_name,
            config_name=cfg.dataset_config,
            max_tokens=max_tokens or cfg.max_train_tokens,
        )
        return DataLoader(
            ds,
            batch_size=cfg.per_device_train_batch_size,
            num_workers=cfg.dataloader_num_workers,
            pin_memory=cfg.dataloader_pin_memory,
        )

    def get_sft_loader(self, cfg, max_tokens: Optional[int] = None) -> DataLoader:
        ds = SFTDataset(
            self.processor,
            max_tokens=max_tokens or cfg.max_train_tokens,
        )
        return DataLoader(
            ds,
            batch_size=cfg.per_device_train_batch_size,
            num_workers=cfg.dataloader_num_workers,
            pin_memory=True,
        )

    def get_dpo_loader(self, cfg) -> DataLoader:
        ds = DPODataset(
            dataset_name=cfg.dataset_name,
            max_samples=cfg.max_train_samples,
        )
        return DataLoader(ds, batch_size=cfg.per_device_train_batch_size,
                          num_workers=1)
