"""
Data Processor — Tokenisation & Cleaning
==========================================
Handles text cleaning, deduplication (heuristic), and tokenisation
for all three training phases.

Updated May 2026: Added tokenize_sft_text() for single-string SFT,
improved quality filter, and robust special token handling.
"""

import re
import unicodedata
from typing import List, Dict, Optional
from transformers import AutoTokenizer, PreTrainedTokenizer


# ─────────────────────────────────────────────────────────────────────
# Text cleaning
# ─────────────────────────────────────────────────────────────────────

def clean_text(text: str) -> str:
    """Basic cleaning: Unicode normalise, strip junk, collapse whitespace."""
    text = unicodedata.normalize("NFKC", text)
    # Remove null bytes and control chars (except newline/tab)
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)
    # Collapse whitespace runs
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def is_quality(text: str, min_chars: int = 200, max_chars: int = 100_000) -> bool:
    """Heuristic quality gate: length, alphabet ratio, degenerate check."""
    if not text or not (min_chars <= len(text) <= max_chars):
        return False
    alpha = sum(c.isalpha() for c in text)
    if alpha / max(len(text), 1) < 0.4:
        return False
    # Reject lines that are mostly repeated words (spam)
    words = text.split()
    if len(words) > 10 and len(set(words)) < max(len(words) * 0.3, 5):
        return False
    return True


# ─────────────────────────────────────────────────────────────────────
# Chat / CoT formatting templates
# ─────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = (
    "You are Yeti Nepal, a helpful and thoughtful AI assistant. "
    "When solving complex problems, think step by step inside <think> tags, "
    "then give your final answer inside <answer> tags."
)


def format_chat(system: str, user: str, assistant: str) -> str:
    """Format a single-turn conversation into a training string."""
    parts = []
    if system:
        parts.append(f"<|system|>\n{system}")
    parts.append(f"<|user|>\n{user}")
    parts.append(f"<|assistant|>\n{assistant}")
    return "\n".join(parts)


def format_cot(question: str, thought: str, answer: str) -> str:
    """Format a chain-of-thought example."""
    return (
        f"<|user|>\n{question}\n"
        f"<|assistant|>\n<think>{thought}</think>\n<answer>{answer}</answer>"
    )


# ─────────────────────────────────────────────────────────────────────
# Processor class
# ─────────────────────────────────────────────────────────────────────

class YetiDataProcessor:
    """
    Tokenises and chunks text for training.

    Args:
        tokenizer_name: HuggingFace tokenizer repo ID
        seq_len: target sequence length for packing
    """

    def __init__(self, tokenizer_name: str, seq_len: int = 2048):
        self.seq_len = seq_len
        self.tokenizer: PreTrainedTokenizer = AutoTokenizer.from_pretrained(
            tokenizer_name, use_fast=True, trust_remote_code=True
        )
        # Ensure pad_token is set (many tokenizers lack one)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id

    # ── Phase 1: Pretraining ──────────────────────────────────────

    def tokenize_pretrain(self, examples: Dict) -> Dict:
        """Tokenise a batch of raw text (streaming pretrain)."""
        texts = [clean_text(t) for t in examples["text"]]
        texts = [t for t in texts if is_quality(t)]
        if not texts:
            return {"input_ids": [], "labels": []}
        enc = self.tokenizer(
            texts,
            add_special_tokens=True,
            truncation=False,
            return_attention_mask=False,
        )
        # Concatenate all tokens into one stream then chunk
        all_ids = []
        for ids in enc["input_ids"]:
            all_ids.extend(ids)
            all_ids.append(self.tokenizer.eos_token_id)

        chunks = self._chunk(all_ids, self.seq_len)
        return {"input_ids": chunks, "labels": chunks}

    # ── Phase 2: SFT (single pre-formatted string) ───────────────

    def tokenize_sft_text(self, text: str) -> Dict:
        """
        Tokenise a single already-formatted SFT string.
        Called by the loader after schema normalisation.
        Returns flat lists (not batched).
        """
        text = clean_text(text)
        if not text or len(text) < 20:
            return {"input_ids": [], "attention_mask": [], "labels": []}

        enc = self.tokenizer(
            text,
            add_special_tokens=True,
            truncation=True,
            max_length=self.seq_len,
            padding="max_length",
            return_attention_mask=True,
        )

        ids  = enc["input_ids"]
        mask = enc["attention_mask"]
        # Mask padding tokens in labels with -100 so they're ignored by loss
        labels = [-100 if m == 0 else i for i, m in zip(ids, mask)]

        return {
            "input_ids":      ids,
            "attention_mask": mask,
            "labels":         labels,
        }

    def tokenize_sft(self, examples: Dict) -> Dict:
        """
        Legacy batch API: Format and tokenise instruction examples.
        Handles ShareGPT (conversations) and prompt/response schemas.
        """
        texts = []

        # Schema 1: ShareGPT conversations [{from, value}, ...]
        for conv in examples.get("conversations", []):
            if isinstance(conv, list) and len(conv) >= 2:
                user_msg = next((c["value"] for c in conv if c.get("from") == "human"), "")
                asst_msg = next((c["value"] for c in conv if c.get("from") == "gpt"), "")
                sys_msg  = next((c["value"] for c in conv if c.get("from") == "system"), SYSTEM_PROMPT)
                if user_msg and asst_msg:
                    texts.append(format_chat(sys_msg, user_msg, asst_msg))

        # Schema 2: Direct prompt/response fields
        if not texts:
            prompts   = examples.get("prompt", [])
            responses = examples.get("response", [])
            for p, r in zip(prompts, responses):
                if p and r:
                    texts.append(format_chat(SYSTEM_PROMPT, p, r))

        # Schema 3: Orca-style (system_prompt, question, response)
        if not texts:
            questions = examples.get("question", [])
            responses = examples.get("response", [])
            systems   = examples.get("system_prompt", [])
            for i, (q, r) in enumerate(zip(questions, responses)):
                sys_p = systems[i] if i < len(systems) else SYSTEM_PROMPT
                if q and r:
                    texts.append(format_chat(sys_p, q, r))

        if not texts:
            return {"input_ids": [], "labels": [], "attention_mask": []}

        enc = self.tokenizer(
            texts,
            add_special_tokens=True,
            truncation=True,
            max_length=self.seq_len,
            padding="max_length",
            return_attention_mask=True,
        )
        labels = [
            [-100 if m == 0 else i for i, m in zip(ids, mask)]
            for ids, mask in zip(enc["input_ids"], enc["attention_mask"])
        ]
        return {
            "input_ids":      enc["input_ids"],
            "attention_mask": enc["attention_mask"],
            "labels":         labels,
        }

    # ── Phase 3: DPO ─────────────────────────────────────────────

    def tokenize_dpo(self, examples: Dict) -> Dict:
        """Tokenise DPO preference pairs {prompt, chosen, rejected}."""
        prompts   = examples.get("prompt", [])
        chosen    = examples.get("chosen", [])
        rejected  = examples.get("rejected", [])
        result = {"prompt": [], "chosen": [], "rejected": []}
        for p, c, r in zip(prompts, chosen, rejected):
            result["prompt"].append(p)
            result["chosen"].append(c)
            result["rejected"].append(r)
        return result

    # ── Utility ──────────────────────────────────────────────────

    def _chunk(self, token_ids: List[int], chunk_size: int) -> List[List[int]]:
        """Split a flat token list into fixed-size chunks (drop last partial)."""
        return [
            token_ids[i: i + chunk_size]
            for i in range(0, len(token_ids) - chunk_size + 1, chunk_size)
        ]
